# Proposed next GAS configuration — 17 October 2026

The subsequent [accuracy-first analysis](accuracy_analysis.md) identifies
relevance scoring, score-consistent initialization/ordering, context coverage,
and candidate coverage as separate quality questions. Treat the numerical
candidate below as a controlled comparison, not an established accuracy winner.
For a new relevance branch, use that branch's top-eight initialization and
ordering and retune its penalty; the primary dense-only candidate below keeps
the original cosine policy.

## Decision and evidence status

**The recommended first candidate is lambda 0.05 with eight-bit coefficients,
15 candidates, eight outputs, and the current 64-call/32-trial GAS budget.**
Keep the pinned encoder, preprocessing, shortlist, initialization, growth factor,
ordering, seeds, and quality margin unchanged for this controlled comparison.

This is an engineering recommendation, not a measured optimum. No new model
inference, dataset evaluation, selector run, unit test, or paper build was
performed during this analysis. Research source, existing manifests, and the
manuscript were not changed. All evaluations remain stopped. The machine-readable
proposal is [proposed_hyperparameters.json](proposed_hyperparameters.json).

The earlier penalty-only note recommended 0.05 at six bits to isolate one change.
Retain that as an ablation. The expanded proposal recommends eight bits for the
next main candidate because coefficient rounding is a separate issue. Compare
the changes separately before attributing any gain to either one.

## Exact proposed settings

| Setting | Completed SciFact | Recommended next candidate | Reason |
|---|---:|---:|---|
| Diversity weight | 0.10 | **0.05** | Weaker continuous relevance/diversity trade-off |
| Coefficient precision | 6 bits | **8 bits** | Finer integer representation; weaker penalties remain meaningful |
| Dense shortlist | 64 parents | 64 parents | Preserve retrieval coverage and comparability |
| GAS candidate pool | 15 parents | 15 parents | Preserve the comparison and avoid a large state-space increase |
| Selected documents | 8 | 8 | Preserve output cardinality and metric cutoffs |
| Phase-oracle-call cap | 64 | 64 | Avoid automatically paying more search cost |
| Measured-trial cap | 32 | 32 | Change only after measuring an accuracy/cost benefit |
| Adaptive window growth | 1.2 | 1.2 | Retain the established randomized schedule |
| Cooperative time cap | 15 seconds | 15 seconds | Preserve existing failure/budget accounting |
| Initialization | Cosine top eight | Cosine top eight | Preserve the comparison and attribution |
| Final ordering | Original cosine | Original cosine | Preserve the approved selection/ordering design |
| Seeds | 0, 1, 2, 3, 4 | 0, 1, 2, 3, 4 | Retain all seeds; average within query |
| Primary quality margin | 0.01 nDCG@5 | 0.01 nDCG@5 | Preserve the declared quality standard |

The existing CLI can express this numerical candidate using
`--gas-weight 0.05 --gas-coefficient-bits 8`. No CLI command was run. Omitting
the explicit weight would invoke the old development grid, which contains only
0.10, 0.25 and 0.50. The proposed numerical candidate is not a changed default.

## Why change precision as well as examine the penalty?

In the current implementation, with Q = 2^b - 1 and k = 8:

```text
linear_i = round(Q * (1 + query_cosine_i) / 2)
pair_ij = round(Q * 2 * lambda / 7 * similarity_ij)
```

At six bits and lambda 0.025, every pair cost is zero. At six bits and lambda
0.05, pair costs first become nonzero above approximately 0.55556 similarity.
At eight bits and lambda 0.05, the first threshold is approximately 0.13725,
with several integer levels rather than one. These are rounding thresholds,
not validated thresholds for semantic duplication. Higher precision changes
which pairs receive a cost as well as how finely they are distinguished.

| Precision | Q | Query-cosine difference corresponding to one linear step |
|---|---:|---:|
| 6 bits | 63 | 0.031746 |
| 8 bits | 255 | 0.007843 |
| 10 bits | 1,023 | 0.001955 |

Eight bits reduces the coefficient step by about four times relative to six
bits. It does not imply a fourfold quality improvement. For eight selected
documents, a conservative per-set continuous-utility approximation bound is
9/(4Q), obtained by adding half-unit errors from eight linear and 28 pair
coefficients, then dividing by 8Q. This bound falls from 0.035714 at six bits
to 0.008824 at eight bits. It is a loose arithmetic bound, not an nDCG bound.

The 6,435 compact basis states do not increase with coefficient precision.
Native reversible arithmetic needs separate value-register and gate-resource
accounting; the extra precision is not free on physical quantum hardware.
The [GAS oracle paper](https://arxiv.org/pdf/1912.04088) discusses both
integer encoding and real-coefficient handling. A later
[real-valued HUBO study](https://arxiv.org/abs/2205.15478) also treats the
representation issue explicitly. Neither establishes eight bits as optimal
for this retrieval task; that choice is our proposed compromise.

## What the saved data can and cannot tell us

The full 161-query development grid used the exact six-bit optimizer:
lambda 0.10/0.25/0.50 gave nDCG@5 0.666543/0.650671/0.573251, respectively;
cosine gave 0.666123. It did not test weaker positive weights. It supports
avoiding the larger penalties but does not establish 0.05 as better than 0.10.

The saved 16-query integration pilot is also development data. Its means were:

| Method in the saved development pilot | nDCG@5 |
|---|---:|
| Cosine | 0.666469 |
| Exact unrounded optimizer, lambda 0.10 | 0.666469 |
| Exact six-bit optimizer, lambda 0.10 | 0.690647 |
| Bounded GAS, lambda 0.10 | 0.695016 |
| Cosine/BM25 reciprocal-rank fusion | 0.764552 |

This pilot is too small to select final parameters. It is useful diagnostically:
the exact unrounded optimizer does not have the highest judged relevance, and
the bounded GAS result can have better relevance than the exact integer result.
**Better optimization of our surrogate is not equivalent to better nDCG.**
Higher precision and more Grover calls therefore require quality evaluation,
not just an improved optimum-hit percentage.

The complete SciFact test run remains recorded and unchanged. Its unrounded,
six-bit exact and bounded GAS nDCG@5 values were 0.635539, 0.632225 and 0.631067.
These differences motivated the numerical diagnosis. They are not evidence for
an unmeasured eight-bit or weaker-penalty result. Any revised SciFact result
must be described as a follow-up informed by the original experiment.

## Why leave the search schedule and pool size alone initially?

[Boyer, Brassard, Hoyer and Tapp](https://arxiv.org/pdf/quant-ph/9605034)
give a randomized search schedule for an unknown number of marked states and
use growth factor 6/5. Keep that factor instead of inventing a fixed iteration
count that assumes knowledge of the improving-state count.

Increasing phase calls/trials to 128/64 is a useful later quality/cost ablation,
not an automatic improvement. It can better optimize a relevance surrogate
while making judged relevance worse, and it adds computation. Never use the
known exact optimum or marked-state count to select GAS iterations or to stop
ordinary search. Keep all failures and returned incumbents in denominators.

Moving from 15 to 20 candidates while keeping eight outputs raises the number
of feasible subsets from 6,435 to 125,970, approximately 19.58 times as many.
It does not guarantee a proportional measured latency increase, but it is a
substantial expansion. It should be a separate scaling/coverage study.

Keep the encoder, model revisions, chunking and output size fixed. Changing
them simultaneously would obscure the causes and require new corpus artifacts.

## Two implementation controls worth adding separately

These are proposed controls, not implemented or benchmarked changes.

### Real-valued compact amplitudes

Proposed control: `simulator_amplitude_dtype = "float64"`.

Our initial uniform amplitudes are real. The only operations are multiplying
marked amplitudes by -1 and reflecting about their mean. Both preserve real
amplitudes, so complex128 storage is mathematically unnecessary for this engine.
Float64 halves amplitude-vector storage, from 102,960 to 51,480 bytes for 6,435
states. That is not a claim about whole-process RAM or a measured speedup.
Numerical equivalence and seed behavior need checks before use. Keep float64,
rather than introducing a lower-precision float32 approximation.

This is a classical simulator optimization. It does not reduce logical quantum
register size or demonstrate a physical quantum advantage.

### Certified initial-state exit

Proposed control: `certified_initial_bound_stop = true`.

For integer energy E(S) = -sum(a_i) + sum(b_ij), with a selected set of k:

```text
L = -sum(k largest linear coefficients)
    + sum(C(k, 2) smallest off-diagonal pair coefficients)
```

The pair coefficients must be taken once per unordered pair, from all candidate
pairs. Every selected set uses k linear terms and C(k,2) distinct pair terms,
so L is a valid lower bound even when the two independently minimizing choices
cannot be realized by one set. If the initial cosine set has E(initial) = L,
it is already globally optimal for the integer objective. The current strictly
improving GAS could never replace it. Returning it immediately preserves that
result while avoiding enumeration and search for this case.

If the equality does not hold, run ordinary bounded GAS. No exact optimizer,
exhaustive energy minimum, improving-state count, or relevance judgments are
used in this check. Count the bound computation as classical preparation and
record the certified status and fraction of requests. The test may rarely
trigger; its overall latency benefit must be measured, including its overhead.
All timed comparators must receive fair implementation treatment.

The equality case is a mathematical certificate, not a guessed stagnation limit.
Do not introduce an arbitrary early-stop patience that may cut useful search.

## One optional new relevance hyperparameter

The strongest plausible extension is **lexical weight beta**, initially **0.25**,
with the dense-only version as the primary controlled candidate. It would mix
BM25 word matching with MiniLM semantic evidence before GAS selection.

The original [RRF paper](https://plg.uwaterloo.ca/~gvcormac/cormacksigir09-rrf.pdf)
motivates combining rank lists and uses k=60. Our saved pilot already supplies
a promising RRF reference. However, the later
[analysis of fusion functions](https://arxiv.org/html/2210.11934v2) finds
normalized convex score combinations competitive or superior in its experiments
and shows that RRF parameters also matter. That motivates a small, normalized
one-weight score mixture; it does not prove which fusion wins here.

An explicit proposed branch, over the existing fixed 64-parent dense shortlist:

```text
dense_i = (1 + cosine_i) / (1 + maximum shortlist cosine)
lexical_i = BM25_i / maximum shortlist BM25
h_i = (1 - beta) * dense_i + beta * lexical_i
```

Use the maxima over all 64 parents and reuse those values when examining the
15-candidate pool. Do not normalize separately for every possible selected set.
BM25 in the current implementation is nonnegative. If its maximum is zero,
use the dense channel alone. A shortlist with a near-zero dense denominator
also needs a documented deterministic dense normalization fallback; do not
divide by zero or turn numerical noise into confidence. Scores are normalized
evidence, not calibrated relevance probabilities.

For the first branch comparison, retain the same 15 cosine candidates. Keep
their original MiniLM vectors and representative passages for redundancy.
The hybrid score replaces only the relevance coefficients. Returning selected
documents in hybrid-score order would be a separate ordering policy from the
approved cosine order; report both as an explicit ablation rather than silently
switching. This branch needs implementation and tests before collection.

Beta 0.25 is a conservative proposed starting weight, not a measured optimum.
Use development candidates {0, 0.25, 0.50, 0.75, 1.0}, plus the existing RRF
reference. Because the new normalization changes score scale, retune lambda
within that branch. Do not assume a dense-only lambda transfers unchanged.
Compare with hybrid-only ranking, hybrid greedy/exact selection, and matched
neural/MMR controls as appropriate. Any gain from lexical evidence must not be
attributed solely to Grover. Avoid adding a similarity threshold, protected
top-five rule, or further weight knobs until these simpler questions are settled.

## Small, ordered development study for the eventual final choice

This describes future work; it is not an instruction to run while paused.

1. Reuse the recorded 161 SciFact development queries and fixed source/model
   configuration. The 16-query pilot remains an integration check, not the
   parameter-selection sample. Use the actual bounded GAS and all five seeds.
2. At eight bits, compare lambda {0, 0.025, 0.05, 0.075, 0.10}. Include the
   original six-bit/0.10 control and six-bit/0.05 to separate the two changes.
   If numerical fidelity still looks material, add one ten-bit/0.05 diagnostic,
   not an unrestricted precision sweep.
3. Use mean development nDCG@5, averaging seeds within each query, as the
   relevance-first choice. Numerical ties within 1e-12 favor lower redundancy,
   then smaller lambda. Retain the zero-diversity outcome if it wins; do not
   force a positive weight to manufacture an advantage. Keep the original
   diversity-first tuning rule in the historical record.
4. For at most the top two numerical candidates, compare 64/32 with 128/64.
   Report quality and median/P95 cost together. More calls are not selected
   merely because the exact-energy hit rate increased. If relevance does not
   improve, keep the lower-cost setting. Report trade-offs rather than claim a
   single universal optimum when quality and cost disagree.
5. Evaluate the implementation controls in paired comparisons with identical
   objective, budgets, inputs and seeds. Separate their simulator performance
   effect from relevance/precision changes and from physical-QPU claims.
6. Explore the lexical-weight branch separately, first checking hybrid-only
   relevance on development queries. Only then tune its GAS penalty and compare
   ordering. Do not run a large Cartesian product of all possible controls.
7. Freeze the development-selected configuration and identify every change in
   a new manifest. Run a separately tagged SciFact follow-up once; preserve the
   original result. Do not repeatedly search the SciFact test set for the best
   seed, penalty, precision, cutoff or quality margin.

The [model-selection study by Cawley and Talbot](https://jmlr.org/papers/v11/cawley10a.html)
explains why selecting against finite evaluation results can bias performance
claims. We have already seen SciFact and preliminary NFCorpus results, so their
revised results need transparent iteration history. Preserve still-unconsulted
evaluation evidence, including the current FiQA test run, for stronger checks
after development choices are frozen.

The [SciFact task](https://aclanthology.org/2020.emnlp-main.609/) concerns evidence
for scientific claims. Reduced embedding similarity is not itself evidence of
better claim retrieval. Keep judged relevance, useful diversity, measured cost,
and optimization success distinct throughout the paper.
