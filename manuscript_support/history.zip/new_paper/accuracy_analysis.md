# Accuracy-first analysis and proposed experiments — 17 October 2026

## Recommendation

**The next accuracy-oriented change should improve the relevance information
and ordering used by GAS, rather than only adjust its search budget or penalty.**
The strongest supported first variant uses the already-pinned L6 cross-encoder
to score query–document relevance, initializes GAS from that score's top eight,
and orders the selected eight by the same score. Keep a cheaper cosine/BM25
hybrid-guided variant as a separate comparison. Both require a score-only
baseline so their relevance gains are not automatically attributed to Grover.

The previous lambda-0.05/eight-bit proposal remains a useful numerical control.
It is not an empirically selected best-accuracy configuration. Different
relevance scores change the penalty's effective scale, so each new relevance
branch needs development selection, including a zero-penalty control.

This document records source inspection, primary research and descriptive
analysis of already-saved metrics. No new rankings, model inference, dataset
runs, hyperparameter sweeps, unit tests or paper builds were performed. The
implementation, manuscript, original scores and manifests remain unchanged.
The derived counts below are transparent post-hoc diagnostics, not new
confirmatory experiments or inputs to test-set parameter fitting.

## What accuracy means here

The current task measures retrieval quality using BEIR relevance judgments.
Our main ranking metric is nDCG@5; Recall@8 checks how much judged-relevant
material remains among the eight returned documents. MRR@5 and precision
provide additional views. An nDCG value of 0.679 is not 67.9% classification
accuracy, and these retrieval runs do not evaluate claim-veracity prediction
or generated-answer correctness.

The original [SciFact task](https://aclanthology.org/2020.emnlp-main.609/)
includes evidence that supports or refutes scientific claims. Relevance cannot
be defined as agreement with the query. Related scientific studies can also
be useful corroborating evidence even when their embeddings are similar.
BEIR retrieval qrels, rather than a hand-written agreement rule, determine
the metric used in this experiment.

## Evidence from the completed corrected run

Source: `research/runs/20261017T055641Z_gas_scifact_corrected/scores.json`.
All values are recorded means over the same 300 queries. Stochastic metrics
average seeds within query. See [accuracy_diagnostics.json](accuracy_diagnostics.json)
for the complete descriptive comparisons.

| Existing method | Candidate pool | nDCG@5 | Recall@8 |
|---|---|---:|---:|
| Cosine | Same 15 | 0.636077 | 0.811111 |
| Current GAS | Same 15 | 0.631067 | 0.774156 |
| Exact unrounded objective | Same 15 | 0.635539 | 0.771000 |
| Exact six-bit objective | Same 15 | 0.632225 | 0.768222 |
| Cosine/BM25 RRF | Same 15 | 0.667676 | 0.814889 |
| L6 cross-encoder | Same 15 | 0.678960 | 0.810389 |
| L6 cross-encoder | Full 64 | 0.681474 | 0.808722 |

The larger L6 pool gave only a small increase in mean nDCG in this run. Its
existence does not prove that the 15-candidate pool has sufficient recall for
every query. However, the much stronger L6 result within the same 15 candidates
shows that candidate count is not the only issue. Better relevance assessment
and ordering are a more directly supported first investigation than increasing
the quantum subset space.

Comparing the saved query-level GAS and cosine metrics:

- nDCG@5 improved on **15 queries**, worsened on **15**, and was equal on
  **270**. The losses were larger in aggregate: mean difference -0.005010.
- Recall@8 improved on **2 queries**, worsened on **26**, and was equal on
  **272**. Mean Recall@8 fell by **0.036956**, or about **3.70 percentage points**.
- Equal metric values do not imply identical rankings. These counts compare
  saved seed-averaged metrics, not 1,500 independent test queries.

Thus current GAS is sometimes removing judged-relevant material that cosine
already retained. The loss is not solely an ordering issue.

For reference, saved fusion versus cosine improved nDCG@5 on 59 queries,
worsened it on 23 and equaled it on 218. Matched L6 versus cosine improved it
on 68, worsened it on 42 and equaled it on 190. These are descriptive patterns,
not newly tested significance claims or guarantees for a revised method.

The 16-query development integration pilot also had higher mean nDCG for
fusion and L6 than cosine. It is too small to select parameters. Use the full
recorded 161 development queries for the next selection study.

## Why the current design has an accuracy limitation

### The oracle has no stronger relevance signal than cosine

Current relevance coefficients are `(1 + cosine(query, document)) / 2`.
The second term penalizes average pair similarity. Grover searches for a set
that improves this supplied objective; it does not learn that one study is
actually better evidence than another. The
[GAS optimization paper](https://arxiv.org/abs/1912.04088) defines search in
terms of a provided objective. It does not establish a retrieval-quality
improvement from replacing a classical optimizer with GAS.

The [embedding model card](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2)
supports semantic search as an intended use; the model is not inherently an
incorrect choice. But embedding similarity is still a surrogate for judged
relevance. A query–document model can provide additional evidence because it
processes their tokens jointly, as explained in the official
[retrieve-and-rerank documentation](https://www.sbert.net/examples/sentence_transformer/applications/retrieve_rerank/README.html).

### The output order reuses the original cosine scores

Current GAS selects eight documents and `cosine_order` sorts that set by the
original scores. It can promote a retained document by excluding documents
above it, but it cannot learn a new relevance ordering between two retained
documents. If a stronger scorer is added, immediately sorting its result back
into cosine order can discard part of that scorer's benefit.

### Mean set utility is not nDCG@5

The objective treats average relevance over eight documents and average pair
similarity as its two components. nDCG@5 instead emphasizes the first five
positions and their judged relevance. Optimizing the former exactly need not
optimize the latter. The saved exact-optimizer results already show that
better optimization alone does not guarantee better nDCG or Recall@8.

Reducing the penalty can recover behavior closer to the original ranking.
Adding numerical bits can reduce coefficient distortion. Neither supplies
missing relevance information. More Grover calls can optimize the same
imperfect surrogate more thoroughly without improving retrieval quality.

## First proposed accuracy variant: relevance-guided GAS

Keep the existing 15 cosine candidate IDs and representative passages for the
first controlled comparison. Use the existing frozen
`cross-encoder/ms-marco-MiniLM-L6-v2`, revision
`233902d25c440f23af6f7d6e94d2946bac0bee0a`. No larger or newly trained model
is required for this initial experiment.

```text
Existing cosine shortlist → existing top 15 parents
  → L6 scores each query–document pair
  → initialize with the eight highest L6 scores
  → GAS jointly selects eight using L6 relevance plus a small pair penalty
  → order those eight by the original, unrounded L6 scores
```

The paired question is whether adding GAS preserves or improves the quality
of this same L6 scorer while producing a useful set-level benefit. Compare
with L6-only ranking and with greedy/exact selection using the same relevance
values, passages, normalization, pool, and output size.

This is a change from the earlier cosine-ordering design and needs a separately
identified method and artifact version. Grover remains the joint set selector.
The relevance model supplies its information; it is not a replacement for
Grover or evidence that Grover caused every pipeline improvement.

### Score normalization is necessary and must be explicit

The pinned L6 model's locally cached configuration specifies an Identity
activation. Its outputs must not simply be assumed to be calibrated [0,1]
relevance probabilities. Sorting raw scores is fine; inserting unbounded
values into the existing cosine coefficient field is not.

A simple proposed fixed normalization is min-max scaling over all 15 candidate
scores for that query. Freeze these bounds before considering subsets. If the
range is numerically zero, assign the same relevance coefficient to every
candidate and retain deterministic raw-score/document-ID tie-breaking. These
normalized scores remain ranking evidence, not probabilities. Keep raw scores
for output ordering. Record the normalization in the manifest and select the
penalty for that scale on development data.

Store relevance scores separately from original cosine values. Keep original
MiniLM document embeddings for the pair-similarity term. Do not overwrite
cosine fields with L6 values while retaining cosine provenance labels.

### Initialization must follow the new score

If relevance changes to L6 or a hybrid score, the initial incumbent should be
its own top eight, rather than the old cosine top eight. This avoids requiring
bounded GAS to rediscover an already-available high-quality score-only set.

With zero diversity weight, that top-eight set already maximizes the monotone
rounded linear relevance sum. Strictly improving GAS cannot replace it, so the
output must match the corresponding score-only baseline, including its tie
policy. This is an important future correctness check. A zero-penalty branch
that loses quality relative to its own score-only baseline would indicate an
implementation or protocol mismatch, not a necessary quantum trade-off.

L6 inference cost belongs to every L6-guided online request. Caching its scores
for an offline development sweep is sensible, but must not make the published
online comparison appear cheaper than running L6 alone.

## Second accuracy question: is the reranker seeing enough evidence?

`FeatureBuilder` currently supplies one maximum-cosine chunk per parent to
the neural baseline. That passage contains at most 190 content tokens. Other
parts of the title/abstract may contain useful evidence. This is a plausible
limitation, not a demonstrated cause of a particular loss in this run.

After the fixed-context relevance variant is measured, test full title/abstract
input when it fits the model's query–document token budget. For longer documents,
test explicit overlapping windows and aggregate their relevance scores, rather
than silently truncate. Use the actual cross-encoder tokenizer and reserve
space for the full query and pair-special tokens.

The [VerT5erini paper](https://aclanthology.org/2021.louhi-1.11.pdf) uses
overlapping abstract segments and maximum segment relevance; its example policy
uses six sentences with stride three. It also studies task/domain adaptation.
These are reasons to investigate context coverage, not guaranteed improvements
or directly comparable numbers for our nDCG@5 experiment. Window lengths must
also satisfy the chosen model's token budget.

Apply an identical context policy to L6-only and L6-guided GAS. Extra windows
cost inference and may introduce noisy matches; report both quality and full
cost. Do not attribute a context-only gain to the quantum selector.

## Cheaper accuracy branch: hybrid-guided GAS

Use the same relevance-guided initialization and ordering rule with a normalized
MiniLM/BM25 hybrid score instead of L6. The proposed lexical weight beta=0.25
is only a starting candidate; evaluate the weights on development judgments.
Maintain the existing RRF reference as well. The
[analysis of hybrid fusion functions](https://arxiv.org/html/2210.11934v2)
supports investigating normalized mixtures and reports that fusion choices and
parameters affect ranking quality. It does not establish a best beta here.

The same-score hybrid-only ranker is the key control. At zero penalty the
hybrid-guided GAS result must match it. Positive-penalty results must justify
their relevance/diversity trade-off against that baseline, not only against
the weaker original cosine ranking.

This branch is preferable when avoiding cross-encoder inference cost matters.
Its future accuracy cannot be inferred from the RRF baseline because the
formula, selection and possibly the candidate prefilter differ.

## Candidate coverage: diagnose before expanding the quantum pool

Future development diagnostics should measure judged-relevant coverage in the
original dense top 64, dense top 15, alternative hybrid top 15, and the final
eight. An oracle ordering ceiling computed from development qrels can locate
headroom, but is a diagnostic only and is never provided to the real selector.
We did not compute those new candidate-coverage metrics during this paused
analysis, so their values are not known here.

If relevant parents are missing from the dense shortlist, form a deduplicated
union of dense top 64 and BM25 top 64, fuse it, and classically prefilter to a
fixed-size shortlist and 15-parent GAS pool. This can change which documents
Grover sees while keeping its subset space fixed. It cannot guarantee higher
coverage after prefiltering; measure the resulting pool.

Keep a fixed-pool experiment for attribution and an end-to-end experiment for
pipeline quality. All methods in each matched comparison need identical
candidate IDs. Merely computing BM25 scores inside the old dense top 15 cannot
recover a relevant document that was excluded before that stage.

## If stronger accuracy still requires learning

A later train-only relevance model can combine semantic, lexical and contextual
features, using difficult retrieved negatives and query-level train/dev splits.
The [learning-to-rank overview](https://www.microsoft.com/en-us/research/publication/from-ranknet-to-lambdarank-to-lambdamart-an-overview/)
provides an established alternative to hand-setting all feature weights.
However, target-domain learning is a separate supervised variant with its own
baselines and validation, not a free hyperparameter improvement.

Do not begin with a larger model, broad fine-tuning, or many new features.
First test the relevance and context information already available. The
published domain-adaptation results vary by metric and setting; adapting a
model to SciFact is not a guarantee of better retrieval across all three
datasets. Distinguish frozen pretrained encoders from a whole pipeline tuned
using target-domain development labels when describing zero-shot behavior.

## Development decision and publication evidence

1. Use the full recorded 161 SciFact development queries and all five seeds.
   Cache query features and frozen model scores for offline development work;
   retain their actual cost in separate online measurements.
2. Validate each score-only baseline and its zero-penalty GAS equivalent first.
   Keep eight-bit coefficients and 64 calls/32 trials initially. Inspect
   penalties {0, 0.01, 0.025, 0.05}; no value is declared optimal in advance.
3. Choose by end-to-end mean development nDCG@5, averaging seeds within query.
   Also require scrutiny of Recall@8: first-five preservation must not hide
   loss of evidence among all eight. A conservative proposed development guard
   is no decrease in mean Recall@8 relative to that branch's score-only baseline;
   the zero-penalty control supplies an eligible reference. Freeze the rule
   before execution and retain the zero outcome if it wins.
4. Separate scorer, initialization/ordering, context, candidate-coverage and
   selector contributions. Each additional change needs its own matched
   baseline or ablation. More exact-energy hits do not establish more accuracy.
5. Freeze the configuration before a separately tagged SciFact follow-up.
   Preserve the original inconclusive/negative result and the original MMR
   target. Do not silently change its cutoff, margin, seeds or primary claim.
6. A claim that Grover improves relevance needs a paired comparison with the
   same-score ranker and strong classical set selectors. A pipeline gain over
   cosine alone does not establish a quantum-specific accuracy benefit.
7. Distinguish follow-up exploration from independent confirmation. SciFact and
   preliminary NFCorpus have already informed decisions. Keep unconsulted
   evidence, including the currently uncollected FiQA run, for later checks
   after choices are fixed. The
   [model-selection literature](https://jmlr.org/papers/v11/cawley10a.html)
   explains why repeated selection against evaluation outcomes biases claims.

No method-specific improvement, new accuracy number, or superiority over
traditional rerankers has been established for these proposed variants.
The current highest-priority experiment is the fixed-pool, fixed-context
L6-guided relevance variant, with its L6-only control. Evaluations remain paused.
