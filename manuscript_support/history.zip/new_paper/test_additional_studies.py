"""Synthetic equivalence checks for the synthesis-only paper analysis."""
import unittest
import numpy as np
from qiskit.quantum_info import Statevector
from research.selection import CandidateFeatures, GASConfig, prepare_problem
from research.selection_circuits import reference_circuit
from new_paper.additional_studies import native_reference


class NativeAnalysisTests(unittest.TestCase):
    def test_native_builder_matches_small_verified_reference(self):
        for n, k in ((3, 2), (4, 3)):
            features = CandidateFeatures(tuple(str(i) for i in range(n)), np.linspace(.9, .2, n), np.eye(n))
            problem = prepare_problem(features, GASConfig(candidate_limit=n, selected_count=k, coefficient_bits=3))
            threshold = problem.energy(range(k))
            first = Statevector.from_instruction(reference_circuit(problem, threshold, 1)).data
            second = Statevector.from_instruction(native_reference(problem, threshold)).data
            self.assertAlmostEqual(abs(np.vdot(first, second)) ** 2, 1., places=10)

    def test_native_builder_supports_larger_decision_register_and_bounds_it(self):
        for n in (11, 16):
            features = CandidateFeatures(tuple(str(i) for i in range(n)), np.linspace(.9, .2, n), np.eye(n))
            problem = prepare_problem(features, GASConfig(candidate_limit=n, coefficient_bits=2))
            threshold = problem.energy(range(8))
            if n == 11:
                self.assertEqual(native_reference(problem, threshold).num_qubits,
                                 problem.resources()["logical_total_qubits"])
            else:
                with self.assertRaises(ValueError):
                    native_reference(problem, threshold)
