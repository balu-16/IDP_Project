"""Create the reviewer response and publication checks from completed artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess


HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finalize(args):
    audit = json.loads((HERE / "reproducibility.json").read_text())
    metrics = json.loads((HERE / "metric_crosscheck.json").read_text())
    pdf, aux = Path(args.pdf), Path(args.aux)
    metadata = subprocess.check_output(["pdfinfo", str(pdf)], text=True)
    extracted = subprocess.check_output(["pdftotext", str(pdf), "-"], text=True)
    if "Verified evaluation input pending" in extracted or "??" in extracted:
        raise ValueError("PDF contains pending results or unresolved cross-references")
    count = int(re.search(r"^Pages:\s+(\d+)", metadata, re.M).group(1))
    if count > 8:
        raise ValueError(f"Manuscript exceeds eight pages: {count}")
    fonts = subprocess.check_output(["pdffonts", str(pdf)], text=True)
    lines = fonts.splitlines()
    font_rows = [row.split() for row in lines[2:] if row.strip()]
    if not font_rows or any(len(row) < 5 or row[-5] != "yes" for row in font_rows):
        raise ValueError("Some PDF fonts are not embedded")
    if re.search(r"\bType\s+3\b", fonts):
        raise ValueError("Bitmap Type 3 fonts require correction")
    labels = {key: (value, page) for key, value, page in
              re.findall(r"\\newlabel\{([^}]+)\}\{\{([^}]*)\}\{([^}]*)\}", aux.read_text())}

    def loc(key):
        if key not in labels:
            raise ValueError(f"Missing compiled label: {key}")
        value, page = labels[key]
        prefix = "Table" if key.startswith("tab:") else "Fig." if key.startswith("fig:") else "Section"
        return f"{prefix} {value}, p. {page}"

    data = audit["primary_runs"]
    for row in metrics["datasets"]:
        if row["manifest_sha256"] != data[row["dataset"]]["manifest_sha256"]:
            raise ValueError("Metric cross-check does not match the final paper inputs")
    if len(metrics["datasets"]) != 3:
        raise ValueError("All three datasets require independent metric checks")
    replica_queries = 0
    for name, dataset in data.items():
        root = HERE.parent
        with (root / audit["secondary_run"] / f"{name}_pool_15_traces.jsonl").open() as handle:
            replicas = {row["qid"]: row for row in (json.loads(line) for line in handle)}
        with (root / dataset["path"] / "traces.jsonl").open() as handle:
            for line in handle:
                primary = json.loads(line)
                if primary["qid"] not in replicas:
                    continue
                original = primary["methods"]["gas"]["per_seed_results"]
                repeated = replicas[primary["qid"]]["methods"]["gas"]["per_seed_results"]
                for seed in original:
                    for key in ("energy", "selected_ids", "ranked_ids", "counts", "status"):
                        if original[seed][key] != repeated[seed][key]:
                            raise ValueError(f"Secondary reference differs from primary: {name}/{primary['qid']}/{seed}/{key}")
                replica_queries += 1
    names = {"scifact": "SciFact", "nfcorpus": "NFCorpus", "fiqa": "FiQA"}
    met = sum(row["target"]["met"] for row in data.values())
    samples = [len(row["manifest"]["test_ids"]) for row in data.values()]
    if sum(samples) != 1271:
        raise ValueError("Incomplete full-test coverage")
    conclusion_words = audit["conclusion_word_count"]
    if not 150 <= conclusion_words <= 200:
        raise ValueError("Conclusion length is out of range")
    chosen = ", ".join(f"{names[n]} {row['manifest']['legacy_threshold']}" for n, row in data.items())
    native = audit["additional_results"]["native_synthesis"]
    completed_native = sum(row["status"] == "completed" for row in native)
    hardware = data["scifact"]["manifest"]["hardware"]
    sections = [
        ("Only two datasets limit generalization",
         "Added the official FiQA financial-retrieval corpus alongside scientific SciFact and nutrition-related NFCorpus. "
         "The revised primary evaluation includes every positively judged test query: 300, 323, and 648, respectively "
         "(1,271 total). Corpus counts, development splits, input checksums, and candidate coverage are reported. "
         f"Evidence: {loc('sec:protocol')}; {loc('tab:data')}; {loc('tab:effectiveness')}.") ,
        ("Dependence on classical cosine scores and candidate selection",
         "Made this dependence explicit and changed the quantum task to joint evidence-set selection. Classical exact "
         "cosine retrieves 64 parents; GAS chooses eight from the top fifteen; cosine orders the selected set. Classical "
         "energy enumeration, feature construction, and retrieval remain charged. Exact optimization is a direct control, "
         "and the manuscript does not claim physical quantum acceleration. "
         f"Evidence: {loc('sec:method')}; {loc('fig:pipeline')}; {loc('sec:limits')}.") ,
        ("High Grover P95 execution times",
         "Replaced aggregate five-seed latency with individually measured seeded-request median/P95. The table separates "
         "selector time from composed online latency, which adds query encoding, retrieval, and representative features. "
         "Neural weights and the data-independent subset basis are warm; legacy requests include fresh problem-specific "
         "circuit construction/transpilation. These boundaries and representation differences are stated. CPU time and "
         "isolated feature-level memory are reported without interpreting them as dollar or energy savings. "
         f"Evidence: {loc('tab:latency')}; reproducibility_report.md.") ,
        ("Incomplete hardware specifications",
         f"Recorded {hardware['cpu_model']}, {hardware['logical_cpus']} logical CPUs, "
         f"{hardware['ram_bytes'] / 2**30:.1f} GiB RAM, two CPU compute threads, Python/library versions, thread "
         "environment, and host load. Dataset runs execute sequentially. Shared-desktop timing variation is disclosed. "
         f"Evidence: {loc('sec:protocol')}; reproducibility.json and sealed manifests.") ,
        ("Missing advanced neural or cross-encoder rerankers",
         "Added MS MARCO MiniLM L2 and L6 cross-encoders on both the matched fifteen candidates and the top-64 shortlist, "
         "returning eight results in neural-score order. Immutable model revisions are recorded and held constant across "
         "datasets. The common all-MiniLM embedding encoder is distinguished from these query--passage rerankers. "
         "Claims apply to the tested baselines, not every current reranker. "
         f"Evidence: {loc('tab:effectiveness')}; {loc('tab:latency')}; {loc('tab:comparisons')}.") ,
        ("Uncited or inconsistent figures",
         "Replaced peripheral OCR/UI screenshots with one retrieval/selection diagram, explicitly cited in the method "
         "text. Its labels distinguish classical retrieval, the GAS subset-selection stage, and final cosine ordering. "
         "Figure and table references are sequential and checked against the compiled labels. "
         f"Evidence: {loc('fig:pipeline')}.") ,
        ("Conclusion should be a single 150--200-word paragraph",
         f"Rewrote the conclusion as one paragraph of {conclusion_words} words, generated from the verified outcome. "
         f"It states that the primary joint target passed on {met}/3 datasets, scopes the findings, and retains the "
         f"simulation and deployment-cost limitations. Evidence: {loc('sec:conclusion')}.") ,
        ("Alternative thresholds and no-marked fallback sensitivity",
         "Tuned the legacy threshold on development nDCG@5 over 0.3/0.5/0.7, with a declared tie rule. "
         f"Frozen choices are {chosen}. A separate secondary 64-query sweep per dataset reports effectiveness and "
         "fallback rates using the legacy matched classical-sampling control and its same marking logic. No primary "
         "threshold is retuned from test outcomes. GAS instead updates an incumbent integer-energy threshold and "
         "retains its feasible best incumbent when an improvement is not found. "
         f"Evidence: {loc('tab:thresholds')}; {loc('sec:method')}; sealed tuning/trace artifacts.") ,
        ("Ranking-score transformation and relevance ordering",
         "Retained the original probability-transformed ranking as a legacy comparator, but replaced probability-as-relevance "
         "scoring in the new method with a joint relevance/redundancy objective. Amplitudes affect which set is selected; "
         "original cosine determines the relative ordering of selected documents. This preserves within-set cosine order "
         "without asserting that membership changes necessarily improve nDCG. "
         f"Evidence: {loc('sec:method')}; {loc('tab:optimization')}.") ,
        ("Candidate-set and score-precision circuit resources",
         "Added fixed-output pool studies at 10/12/15/20 candidates, coefficient studies at 2/4/6 bits, quantized/float "
         "optimum gaps, logical-width calculations, and measured compact-simulator costs. Native generic circuits are "
         "additionally synthesized at 10/8, 12/8, and 15/8 for all three precisions, using a predetermined SciFact instance. "
         f"{completed_native}/{len(native)} native cases completed within the 180-second per-case budget; any remaining "
         "cases are explicitly censored. Gate counts include generic state preparation and one amplification iteration. "
         "Compilation is distinguished from circuit execution, and efficient Dicke preparation is not claimed. "
         f"Evidence: {loc('tab:ablations')}; {loc('tab:circuits')}; reproducibility_report.md.") ,
        ("Additional classical reranking comparisons",
         "Added native RRF and MMR, greedy optimization, exact integer and exact float optimization, and budget-matched "
         "uniform random subset search. MMR is development-tuned independently, and native MMR/RRF ordering is retained. "
         "The exact controls use the same objective and reveal whether gains come from the objective or search. "
         f"Evidence: {loc('tab:effectiveness')}; {loc('tab:optimization')}; {loc('tab:latency')}.") ,
        ("Evaluation on a larger document collection",
         "Added FiQA's 57,638-document collection and all 648 judged test queries, compared with 5,183 SciFact and "
         "3,633 NFCorpus parents. This extends classical corpus size and domain coverage. The quantum pool remains fifteen, "
         "so the manuscript explicitly declines to interpret this as quantum search scaling with the entire corpus. "
         f"Evidence: {loc('tab:data')}; {loc('sec:limits')}.") ,
    ]
    response = ["# Response to technical comments — ICECMSN-1883", "",
                "**Paper:** QubitChat: A Controlled Evaluation of Grover-Inspired Reranking for Document Retrieval", "",
                "The revised manuscript replaces the probability-as-relevance policy as the main method with "
                "Grover Adaptive Search for evidence-set selection. The original policy is retained as a legacy "
                "comparison. New protocol/results are reported together; earlier nDCG@10 tables are not mixed "
                "with the revised nDCG@5/eight-output study.", ""]
    for index, (comment, answer) in enumerate(sections, 1):
        response += [f"## Comment {index}: {comment}", "", answer, ""]
    compared = sum(row["compared_values"] for row in metrics["datasets"])
    response += ["## Verification and remaining author actions", "",
                 f"The {count}-page PDF has embedded outline fonts. Independent official trec_eval checks cover "
                 f"{compared:,} numerical metric values across every primary request, within its four-decimal "
                 "printing tolerance. Source/result/data checksums, per-seed coverage, fixed output cardinality, "
                 "confidence intervals, timing boundaries, and the conclusion length are checked. "
                 "A factual AI-assistance acknowledgment is included under the IEEE conference policy. "
                 "Authors still need to review the final manuscript and response, confirm organizer-specific "
                 "camera-ready requirements, and perform submission/copyright/PDF eXpress steps. No submission "
                 "has been performed automatically."]
    (HERE / "reviewer_response.md").write_text("\n".join(response) + "\n")
    shutil.copyfile(pdf, HERE / "main.pdf")
    checks = {"status": "Prepared for author review; not submitted", "pdf_pages": count,
              "pdf_sha256": sha(HERE / "main.pdf"), "fonts_embedded": True, "type3_fonts": False,
              "font_inventory": fonts, "conclusion_words": conclusion_words,
              "independent_metric_values_checked": compared, "trec_eval_commit": metrics["trec_eval_commit"],
              "independent_aggregate_checks": sum(row["independent_aggregate_checks"] for row in metrics["datasets"]),
              "selected_set_geometry_checks": sum(row["selected_set_geometry_checks"] for row in metrics["datasets"]),
              "secondary_reference_reproduced_queries": replica_queries,
              "primary_joint_target_passed_datasets": met, "native_synthesis_completed": completed_native,
              "native_synthesis_cases": len(native), "compiled_labels": labels,
              "source_hashes": {str(p.relative_to(HERE)): sha(p) for p in
                                [HERE / "main.tex", *sorted(HERE.glob("*.py")), *sorted((HERE / "gas_generated").glob("*.tex"))]},
              "audit_sha256": sha(HERE / "reproducibility.json"),
              "metric_crosscheck_sha256": sha(HERE / "metric_crosscheck.json")}
    (HERE / "publication_checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    (HERE / "REVISION_STATUS.md").write_text(
        "# Revision status — 17 October 2026\n\n"
        "Completed: full SciFact (300), NFCorpus (323), and FiQA (648) evaluations; development pilots; "
        "sealed primary/secondary/additional artifacts; independent metric cross-checks; generated numerical "
        "tables and findings; revised LaTeX; reviewer response; and compiled PDF checks.\n\n"
        f"Primary joint target passed on {met}/3 datasets. The paper reports these outcomes without "
        "claiming physical quantum acceleration.\n\n"
        "Final deliverables: `main.pdf`, `main.tex`, `reviewer_response.md`, `reproducibility_report.md`, "
        "`reproducibility.json`, `metric_crosscheck.json`, `publication_checks.json`. "
        "Run directories are recorded in `evaluation_run_paths.json`.\n\n"
        "Status: prepared for author review; organizer submission/copyright/PDF eXpress actions remain "
        "with the authors. Nothing has been submitted automatically.\n")
    print(f"Finalized {count}-page revision; {compared} independent metric values checked; target {met}/3")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", required=True)
    parser.add_argument("--aux", required=True)
    finalize(parser.parse_args())
