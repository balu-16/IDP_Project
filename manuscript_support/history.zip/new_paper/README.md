# Qubit Chat manuscript

The current revision uses **L6-guided GAS** throughout. Its table caption and methods disclose protected-prefix refinement on SciFact/NFCorpus and the earlier base configuration on FiQA. The FiQA 100-query training confirmation is excluded. No new dataset rankings are collected by the manuscript tools.

## Authoritative inputs

[`paper_sources.json`](paper_sources.json) is the only mapping to edit when replacing a completed dataset run:

| Dataset | Full-test source | Queries |
|---|---|---:|
| SciFact | `research/runs/accuracy_v3_redundancy_scifact_test` | 300 |
| NFCorpus | `research/runs/accuracy_v3_redundancy_nfcorpus_test` | 323 |
| FiQA | `research/runs/accuracy_v2_fiqa_test` | 648 |

The exporter requires a complete official **test** run, checks dataset/source/dependency identities and sealed hashes, validates every method/seed checkpoint, independently recomputes nDCG@5/@8, Recall@8 and redundancy from existing rankings, and verifies timing aggregates. It rejects confirmation/dev runs and incomplete results. FiQA's existing numerical-tie statistics audit is verified against its original manifest and evaluation hashes.

Historical scripts, notes and `generated/` fragments are preserved for audit but are not inputs to `main.tex`. The live paper uses `verified_generated/`. Experimental sources and recorded runs must not be edited or resealed to make them pass manuscript checks.

## Regenerate and build

Run from the repository root with the existing virtual environment:

```bash
PYTHONDONTWRITEBYTECODE=1 backend/.venv/bin/python -u new_paper/export_verified_results.py --check-metrics
PYTHONDONTWRITEBYTECODE=1 backend/.venv/bin/python new_paper/build_manuscript.py
```

The first command only reads existing rankings; `--check-metrics` independently verifies all request nDCG@5/Recall@8 values with the existing NIST `trec_eval`. It does **not** initialize models, encode corpora, retrieve candidates, run selectors, or invoke benchmark collection/evaluation commands. The exporter without that flag still independently checks saved summaries; use the flag for final delivery.

The build uses the supplied `IEEEtran.cls` unchanged and local `build/tools/tectonic`. It rejects stale generated inputs, page counts outside 6–8, overfull boxes, unresolved references, nonembedded fonts, Type 3 fonts, an oversized abstract, and missing figure/table citations. It runs small independent mathematical checks without any datasets or inference. Output is `main.pdf`; logs, `.aux`, and intermediate PDF are under `build/manuscript_verified/`.

Equivalent combined command:

```bash
PYTHONDONTWRITEBYTECODE=1 backend/.venv/bin/python new_paper/build_manuscript.py --export --check-metrics
```

For a read-only audit of inputs and generated checksums:

```bash
PYTHONDONTWRITEBYTECODE=1 backend/.venv/bin/python new_paper/export_verified_results.py --check
```

## Replace FiQA after its full new run

1. On a later explicit instruction, complete and seal the new FiQA **648-query test** with its independent metrics, statistics, and report. Dataset execution is outside the manuscript commands above.
2. In `paper_sources.json`, replace only FiQA's directory with the completed new run, normally `research/runs/accuracy_v3_redundancy_fiqa_test`. Keep historical results intact. Do not map the 100-query confirmation directory.
3. Run the combined export/build command. The exporter detects the new schema, uses `gas_v3`, selects its matched controls/statistics, and regenerates metrics, timings, configuration note, abstract findings, and conclusion. The note about FiQA's earlier configuration disappears only when a verified refined test is supplied.
4. Inspect **every page again**. The build regenerates the reviewer response and local publication checks; visual inspection and organizer validation are separate.

## Evidence and delivery files

- `main.tex`, `main.pdf`, and unchanged supplied `IEEEtran.cls`.
- `latex_source.zip`: portable Overleaf source containing the main document, supplied class, all generated LaTeX inputs, and a short build note. Regenerate this archive after changing the manuscript; the workspace source/PDF are authoritative.
- `verified_generated/evidence.json`: complete means, timings, paired statistics, hardware, resource summaries, and verification counts.
- `verified_generated/all_methods.csv`: all 27 SciFact/NFCorpus controls and 20 FiQA controls, with the reported method marked.
- `verified_generated/provenance.json`: generated-file hashes, exporter/source-mapping hashes, and selected manifest/evaluation hashes.
- `reviewer_response.md`: all twelve acceptance-letter comments mapped to compiled sections/tables/pages; the resource-depth comment is only partially addressed.
- `publication_checks.json`: local PDF, mathematical, and provenance checks; page inspection status is recorded separately.
- `reproducibility_report.md`: experiment boundaries and scientific limitations.

## Scientific and publication boundaries

The newer tests are follow-up evaluations after earlier test inspection. NFCorpus's confirmation recall gate failed before an explicitly recorded unchanged-parameter continuation; its full test passing does not erase that deviation. SciFact's relative recall loss is reported. Protected nDCG@5 is a construction guarantee, not a Grover accuracy discovery. Classical greedy/exact refinement matches the reported aggregate quality. Full pipeline latency includes additional neural scoring and is higher than matched base GAS. No Grover speed/cost/superiority claim is established.

Full native constrained-oracle circuit-depth/precision studies remain unperformed. Embedding redundancy is a proxy, and a 98% mean recall gate does not establish statistical noninferiority. A full new FiQA refinement test is not included yet.

Conference format: [ICECMSN 2026 submission guidelines](https://icecmsn.com/2026/submission.html); local supplied template in `conference-latex-template/IEEE-conference-template-062824/`. The AI-assistance disclosure follows [IEEE's conference submission policy](https://conferences.ieeeauthorcenter.ieee.org/author-ethics/guidelines-and-policies/submission-policies/). Local checks do not constitute PDF eXpress or organizer acceptance; no submission, copyright form, or external message is sent automatically.
