# Completed SciFact results — 17 October 2026

All evaluations were stopped at the user’s request after SciFact completed. NFCorpus is paused and must start again only after the user explicitly requests it. No evaluations, unit tests, or paper builds were run to produce this log; it formats saved results.

Authoritative run: `research/runs/20261017T055641Z_gas_scifact_corrected`. Manifest SHA-256: `1ff7d24be19cc391d683706d372a249e67621a28dc69dab606f8129ebde8654d`. This log was recorded at `2026-10-17T06:27:14+00:00`.

Machine-readable full aggregate results, comparisons, development tuning, hardware, model revisions, source/result hashes, and the existing independent checks are in [scifact_results.json](scifact_results.json). Original per-query metrics, rankings, traces, and source snapshots remain in the authoritative run. [evaluation_run_paths.json](evaluation_run_paths.json) contains only the completed corrected SciFact run.

## What improved, and what did not

- Compared with the old probability-based Grover reranker, embedding redundancy fell from **0.4756 to 0.4490** (5.60% relative reduction). This measures pairwise similarity between the eight returned documents; it does not by itself prove better relevance or coverage.
- Mean relevance, measured by nDCG@5, fell slightly: **0.6364 to 0.6311** (difference -0.005296). There is no demonstrated accuracy improvement.
- Median selector time increased from **0.485 to 4.616 ms**. P95 selector time decreased from **150.140 to 6.129 ms**. Legacy Grover used fallback in 995/1,500 requests; this limits any interpretation as an algorithm-only tail-latency advantage.
- GAS is faster than the neural rerankers on this CPU, but its relevance is lower than the matched L2/L6 means. Matched L6 has nDCG@5 **0.6790**, with median selector time **488.131 ms**.
- Greedy selection is cheaper (**0.211 ms**) and has slightly higher mean relevance (**0.6344**) with effectively the same redundancy as GAS. Exact integer optimization is also cheaper (**1.380 ms**) and always reaches the integer optimum. These comparators must be reported.
- Comparing the corrected SciFact rerun with the earlier preliminary SciFact run: all 13 methods have identical nDCG@5, nDCG@8 and Recall@8. The tokenizer correction improved preprocessing correctness, without a measured SciFact relevance gain. The preliminary run remains superseded.

## Frozen protocol

- 300 test queries; 5183 parent documents; 13505 full-text chunks.
- Exact cosine top 64 → top 15 candidate parents → select 8 jointly → order the selected set by original cosine. Matched selectors/neural rerankers use the same 15 candidates; explicitly labeled top-64 comparators see the full shortlist.
- GAS uses 6-bit coefficients, diversity weight 0.1, at most 64 phase calls / 32 trials / 15 seconds per request, and seeds [0, 1, 2, 3, 4]. The time cap is cooperative.
- MMR diversity weight 0.0 was independently selected on development nDCG@5; its result coincides with cosine on this dataset. Legacy threshold 0.7 was selected on development judgments.
- Effectiveness first averages seeds within each query, then averages queries. No best seed or seed ensemble is selected. Timing quantiles use individual requests.
- Representation: exact compact feasible-subset amplitude simulation. All classical subset-energy preparation is charged to GAS. This is not a physical quantum speedup measurement.
- CPU: 13th Gen Intel(R) Core(TM) i7-1355U; two-thread limits; model revisions and package versions are preserved in the JSON and manifest.

## Effectiveness: every method

Higher values are better. All methods return eight documents; @5 metrics assess the first five.

| Method | nDCG@5 | nDCG@8 | MRR@5 | MRR@8 | P@5 | Recall@5 | Recall@8 |
|---|---:|---:|---:|---:|---:|---:|---:|
| cosine | 0.636077 | 0.659553 | 0.607333 | 0.616242 | 0.162667 | 0.745056 | 0.811111 |
| exact_float | 0.635539 | 0.646116 | 0.606833 | 0.610841 | 0.162667 | 0.742833 | 0.771000 |
| exact_quantized | 0.632225 | 0.644636 | 0.605500 | 0.610202 | 0.160667 | 0.735333 | 0.768222 |
| fusion | 0.667676 | 0.687275 | 0.642333 | 0.650310 | 0.167333 | 0.759333 | 0.814889 |
| gas | 0.631067 | 0.646326 | 0.605444 | 0.611758 | 0.159467 | 0.732822 | 0.774156 |
| greedy | 0.634371 | 0.648451 | 0.606722 | 0.611901 | 0.161333 | 0.740889 | 0.778222 |
| legacy_grover | 0.636363 | 0.659274 | 0.607467 | 0.616026 | 0.162800 | 0.746722 | 0.811111 |
| mmr | 0.636077 | 0.659553 | 0.607333 | 0.616242 | 0.162667 | 0.745056 | 0.811111 |
| neural_l2_matched | 0.643114 | 0.666104 | 0.620944 | 0.630071 | 0.162000 | 0.740611 | 0.804889 |
| neural_l2_top64 | 0.632057 | 0.654432 | 0.612222 | 0.620833 | 0.158000 | 0.728556 | 0.791556 |
| neural_l6_matched | 0.678960 | 0.694776 | 0.661000 | 0.666357 | 0.168000 | 0.766278 | 0.810389 |
| neural_l6_top64 | 0.681474 | 0.696617 | 0.666111 | 0.671587 | 0.168667 | 0.767056 | 0.808722 |
| random | 0.631627 | 0.649930 | 0.606544 | 0.613779 | 0.159067 | 0.730956 | 0.781733 |

## Redundancy and optimization

Lower redundancy and gaps are better; higher utility and optimum-hit rate are better. These use the frozen GAS objective and embedding geometry, rather than relevance judgments. A dash means the metric was not defined for that comparator’s pool.

| Method | Redundancy | Utility | Float utility gap | Integer energy gap | Integer optimum hit |
|---|---:|---:|---:|---:|---:|
| cosine | 0.475640 | 0.723984 | 0.002340 | 2.140000 | 0.400000 |
| exact_float | 0.432094 | 0.726324 | 0.000000 | 1.256667 | 0.343333 |
| exact_quantized | 0.445078 | 0.724046 | 0.002278 | 0.000000 | 1.000000 |
| fusion | 0.472726 | 0.721892 | 0.004431 | 3.273333 | 0.123333 |
| gas | 0.448951 | 0.723857 | 0.002466 | 0.380000 | 0.698667 |
| greedy | 0.448951 | 0.724074 | 0.002250 | 0.160000 | 0.876667 |
| legacy_grover | 0.475604 | 0.723985 | — | — | — |
| mmr | 0.475640 | 0.723984 | 0.002340 | 2.140000 | 0.400000 |
| neural_l2_matched | 0.464187 | 0.717581 | 0.008743 | 5.706667 | 0.026667 |
| neural_l2_top64 | 0.432931 | 0.705725 | — | — | — |
| neural_l6_matched | 0.465528 | 0.718071 | 0.008252 | 5.423333 | 0.023333 |
| neural_l6_top64 | 0.437922 | 0.706728 | — | — | — |
| random | 0.456379 | 0.723693 | 0.002631 | 0.956000 | 0.462000 |

## Latency and CPU work

Seeded requests measured individually. Retrieval totals add candidate and representative features; online_total_ms also adds freshly measured query encoding. Model/corpus loading is offline and reported separately.

Times are milliseconds. Selector includes its per-query preparation/search. Retrieval includes candidate retrieval and representative features. Composed online totals additionally charge query encoding. Model/corpus loading is offline. CPU time may exceed wall time with two threads. These measurements do not establish a monetary cost advantage.

| Method | Selector median | Selector P95 | Retrieval median | Retrieval P95 | Online median | Online P95 | Selector CPU median | Selector CPU P95 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| cosine | 0.135 | 0.216 | 9.964 | 16.110 | 17.991 | 27.977 | 0.269 | 0.409 |
| exact_float | 1.435 | 1.780 | 11.269 | 17.431 | 19.285 | 29.395 | 2.868 | 3.403 |
| exact_quantized | 1.380 | 1.758 | 11.239 | 17.347 | 19.214 | 29.247 | 2.747 | 3.308 |
| fusion | 0.149 | 0.193 | 26.404 | 44.852 | 35.276 | 56.668 | 0.299 | 0.372 |
| gas | 4.616 | 6.129 | 14.624 | 21.398 | 22.844 | 35.004 | 9.225 | 12.120 |
| greedy | 0.211 | 0.260 | 10.037 | 16.180 | 18.054 | 28.049 | 0.422 | 0.497 |
| legacy_grover | 0.485 | 150.140 | 11.114 | 169.663 | 20.744 | 179.867 | 1.397 | 160.259 |
| mmr | 0.246 | 0.290 | 10.073 | 16.215 | 18.092 | 28.087 | 0.492 | 0.573 |
| neural_l2_matched | 180.988 | 264.185 | 190.479 | 302.523 | 198.900 | 309.200 | 391.171 | 572.198 |
| neural_l2_top64 | 740.287 | 1107.217 | 750.115 | 1116.717 | 759.725 | 1124.348 | 1479.995 | 2200.105 |
| neural_l6_matched | 488.131 | 695.884 | 498.374 | 706.510 | 506.779 | 717.919 | 975.119 | 1390.852 |
| neural_l6_top64 | 2138.555 | 2842.010 | 2151.150 | 2852.931 | 2158.063 | 2859.260 | 4273.362 | 5652.322 |
| random | 2.260 | 2.906 | 12.064 | 18.596 | 20.213 | 31.598 | 4.508 | 5.680 |

Common query encoding: median 7.922 ms, P95 16.271 ms. Offline recorded stages: `{"bm25_build": 392.02431099965906, "data_independent_subset_basis_setup": 0.0035660004868987016, "dataset_and_corpus_encoding": 380560.80255599954, "test_query_encoding": 2678.781274999892}` (milliseconds).

## Request counts, budgets, and simulator counters

| Method | Requests | Statuses | Recorded phase calls | Recorded simulator objective evaluations |
|---|---:|---:|---:|---:|
| cosine | 300 | completed: 300 | 0 | 0 |
| exact_float | 300 | completed: 300 | 0 | 0 |
| exact_quantized | 300 | completed: 300 | 0 | 0 |
| fusion | 300 | completed: 300 | 0 | 0 |
| gas | 1500 | oracle_budget: 1090; trial_budget: 410 | 86818 | 9652500 |
| greedy | 300 | completed: 300 | 0 | 0 |
| legacy_grover | 1500 | completed: 505; fallback: 995 | 0 | 0 |
| mmr | 300 | completed: 300 | 0 | 0 |
| neural_l2_matched | 300 | completed: 300 | 0 | 0 |
| neural_l2_top64 | 300 | completed: 300 | 0 | 0 |
| neural_l6_matched | 300 | completed: 300 | 0 | 0 |
| neural_l6_top64 | 300 | completed: 300 | 0 | 0 |
| random | 1500 | completed: 1500 | 0 | 0 |

Phase/objective counters are instrumentation fields for GAS. A zero in another method does not mean it performs no computation or has no quantum oracle calls. GAS status indicates its stopping budget, not failed requests; all incumbents remain in the metrics. It reaches the exact integer optimum in 69.87% of query-seed requests; greedy reaches 87.67%.

## Primary statistical target

**Not met on SciFact.** The predeclared target requires both nDCG@5 non-inferiority within 0.01 absolute and a reduction in redundancy relative to independently tuned MMR.

- GAS − MMR nDCG@5: **-0.005010**, paired 95% CI **[-0.012841, +0.002291]**. The lower bound extends below −0.01, so quality non-inferiority is not established.
- GAS − MMR redundancy: **-0.026689**, paired 95% CI **[-0.030409, -0.023126]**. This supports reduced embedding redundancy, conditional on the declared MMR tuning rule.
- Absence of a statistically significant relevance difference is not proof of equal quality. None of the nDCG comparisons survives the recorded Holm family correction. The full paired estimates and correction results are retained below and in JSON.

| Baseline | GAS − baseline nDCG@5 | 95% CI low | 95% CI high | Raw p | Holm significant |
|---|---:|---:|---:|---:|---:|
| cosine | -0.005010 | -0.012841 | +0.002291 | 0.208179 | False |
| exact_float | -0.004472 | -0.012002 | +0.002753 | 0.250575 | False |
| exact_quantized | -0.001158 | -0.005614 | +0.003090 | 0.620038 | False |
| fusion | -0.036609 | -0.061215 | -0.011777 | 0.004200 | False |
| greedy | -0.003304 | -0.009161 | +0.001926 | 0.247175 | False |
| legacy_grover | -0.005296 | -0.014336 | +0.003125 | 0.241976 | False |
| mmr | -0.005010 | -0.012841 | +0.002291 | 0.208179 | False |
| neural_l2_matched | -0.012047 | -0.047704 | +0.022765 | 0.497050 | False |
| neural_l2_top64 | -0.000989 | -0.040431 | +0.037688 | 0.960204 | False |
| neural_l6_matched | -0.047893 | -0.082144 | -0.014633 | 0.004700 | False |
| neural_l6_top64 | -0.050407 | -0.091148 | -0.010995 | 0.012699 | False |
| random | -0.000560 | -0.007171 | +0.005420 | 0.873413 | False |

## Existing verification evidence

Before the user paused work, official NIST trec_eval (commit `35cf096ba6d5ae08ca4803c056b31ed61a56a6d4`) independently checked all 25 primary request groups: **52,500 per-query metric values**, **91 aggregate checks**, and **7,500 selected-set geometry checks**. Maximum difference from four-decimal trec_eval output was **0.0000495432**, within the recorded **0.000051** tolerance. See [metric_crosscheck.json](metric_crosscheck.json). These checks were already complete; they were not rerun while logging.

## Paused work

- NFCorpus: `research/runs/20261017T062257Z_gas_nfcorpus_corrected` is incomplete. It has 23 serialized test-query traces out of 323, 23 selection feature records, and 24 full-shortlist feature records. It has no sealed manifest or scores. These are not final benchmark results.
- NFCorpus full corpus encoding and the 16-query development pilot completed. The verified cache files are preserved, so a future invocation can reuse corpus embeddings if its integrity/configuration checks pass.
- Corrected FiQA collection, secondary ablations, memory/circuit studies, final paper tables/figures, reviewer response and final PDF remain pending.
- No evaluation chain is running. See [RESUME.md](RESUME.md). Start NFCorpus only on a new explicit user instruction; do not automatically proceed to FiQA or secondary studies.
