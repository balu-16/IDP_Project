# Tokenizer initialization correction — 17 October 2026

The pinned tokenizer JSON enables 128-token raw-backend truncation and fixed padding. The old offset-inspection code called the raw backend before Transformers disabled these defaults, affecting the first corpus document. The complete first-document lengths were SciFact 450, NFCorpus 384, and FiQA 100 WordPiece tokens, while the raw default returned 128 for each.

The corrected chunker explicitly disables raw padding/truncation before inspecting the first document, and requests unpadded/untruncated wrapper encoding. Empty-text parents remain in the benchmark and contribute zero to token-length statistics. Synthetic regression tests and a real pinned-model integration check cover first-document coverage and cache integrity.

Earlier completed SciFact/NFCorpus results are superseded diagnostics, preserved in the directories recorded in `superseded_run_paths.json`. They must not supply the revised paper's numbers or be resealed under the corrected source. The initial FiQA encoding was stopped. Every dataset is being recollected with the correction. The algorithm, hypotheses, cutoffs, grids, seeds, and search budgets remain unchanged; this is a preprocessing correction, not test-driven hyperparameter selection.

A corpus-embedding cache is bound to exact chunk inputs, encoder revision, implementation hash, and package versions. Checksums and shape/value checks guard reuse. Cache usage and cold encode/restore timings are explicit in provenance.
