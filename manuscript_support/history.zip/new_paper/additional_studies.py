"""Supplement legacy-threshold sensitivity and full-pool circuit synthesis.

These analyses do not change the frozen primary selection policy. Full-pool
circuit measurements are synthesis only, never physical-QPU execution timing.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
import math
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research.selection import (GASConfig, SelectionResult, prepare_problem, select_classical,
                                selection_metrics, subset_layout)
from research.selection_experiment import (SCHEMA, SEEDS, _sha, _write_json, hardware_record,
                                           seal_run, snapshot_sources, verify_run)
from research.selection_studies import load_sample, take_features


def native_reference(problem, threshold):
    """Literal generic circuit for one step, bounded to at most 15 decisions."""
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import QuadraticForm, StatePreparation

    n, k = len(problem.features.ids), problem.count
    if not 1 <= n <= 15:
        raise ValueError("Native synthesis supports 1--15 decision qubits")
    resource = problem.resources()
    if not resource["energy_lower_bound"] <= threshold <= resource["energy_upper_bound"]:
        raise ValueError("Unsafe native threshold")
    width = resource["value_qubits"]
    amplitudes = np.zeros(1 << n, dtype=np.complex128)
    for subset in subset_layout(n, k):
        amplitudes[sum(1 << int(i) for i in subset)] = 1 / math.sqrt(math.comb(n, k))
    preparation = StatePreparation(amplitudes)
    value = QuadraticForm(width, np.triu(problem.quadratic, 1).tolist(),
                          (-problem.linear).tolist(), -int(threshold), little_endian=True)
    circuit = QuantumCircuit(n + width)
    circuit.append(preparation, range(n))
    circuit.compose(value, inplace=True)
    circuit.z(n + width - 1)
    circuit.compose(value.inverse(), inplace=True)
    circuit.append(preparation.inverse(), range(n))
    circuit.x(range(n))
    if n == 1:
        circuit.z(0)
    else:
        circuit.h(n - 1)
        circuit.mcx(list(range(n - 1)), n - 1)
        circuit.h(n - 1)
    circuit.x(range(n))
    circuit.append(preparation, range(n))
    return circuit


def native_worker(args):
    from qiskit import transpile
    import resource

    run = Path(args.run)
    manifest = verify_run(run)
    qid = manifest["secondary_sample_ids"][0]
    features = load_sample(run, [qid])[qid]
    cfg = replace(GASConfig(**manifest["config"]), candidate_limit=args.pool, coefficient_bits=args.bits)
    problem = prepare_problem(take_features(features, args.pool), cfg)
    threshold = problem.energy(problem.cosine_order()[:problem.count])
    start = time.perf_counter()
    circuit = native_reference(problem, threshold)
    build_ms = (time.perf_counter() - start) * 1000
    start = time.perf_counter()
    compiled = transpile(circuit, basis_gates=["u", "cx"], optimization_level=1, seed_transpiler=0)
    print(json.dumps({"dataset": manifest["canonical_dataset"], "qid": qid, "pool": args.pool,
                      "selected": cfg.selected_count, "bits": args.bits, "qubits": circuit.num_qubits,
                      "depth": compiled.depth(), "gates": {str(k): int(v) for k, v in compiled.count_ops().items()},
                      "build_ms": build_ms, "transpile_ms": (time.perf_counter() - start) * 1000,
                      "process_peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                      "status": "completed", "iterations": 1,
                      "note": "Generic fixed-cardinality StatePreparation. Synthesis only; no QPU execution."}))


def run_studies(args):
    from research import artifacts, baselines, datasets
    from research.config_frozen import FROZEN
    from research.metrics import ndcg_at

    output = artifacts.new_run_dir("gas_additional_studies")
    sources = snapshot_sources(output)
    (output / "additional_studies.py").write_bytes(Path(__file__).read_bytes())
    parents, thresholds, mmr_curves = [], {}, {}
    scifact = None
    for path in args.runs:
        run = Path(path).resolve()
        manifest = verify_run(run)
        name = manifest["canonical_dataset"]
        if name == "scifact":
            scifact = run
        parents.append({"run": str(run), "manifest_sha256": _sha(run / "manifest.json")})
        chosen = set(manifest["secondary_sample_ids"])
        _, _, qrels = datasets.load_beir(name, "test")
        selected_records = []
        with (run / "traces.jsonl").open() as handle:
            for line in handle:
                record = json.loads(line)
                if record["qid"] in chosen:
                    selected_records.append(record)
        rows = []
        for threshold in (0.3, 0.5, 0.7):
            values, fallback_queries = [], 0
            with (output / f"{name}_threshold_{threshold}_traces.jsonl").open("w") as handle:
                for record in selected_records:
                    _, trace = baselines.rerank_frozen(record["shortlist_ids"], record["shortlist_scores"],
                                                       "sampling", threshold, FROZEN["shots"], FROZEN["boost"], list(SEEDS))
                    per_seed = [ndcg_at(rank[:8], qrels[record["qid"]], 5)
                                for rank in trace["per_seed_rankings"].values()]
                    values.append(float(np.mean(per_seed)))
                    fallback_queries += bool(trace["fallback"])
                    handle.write(json.dumps({"qid": record["qid"], "trace": trace}, allow_nan=False) + "\n")
            rows.append({"threshold": threshold, "queries": len(values), "nDCG@5": float(np.mean(values)),
                         "fallback_queries": fallback_queries, "fallback_fraction": fallback_queries / len(values),
                         "primary_chosen_threshold": manifest["legacy_threshold"],
                         "control": "Legacy ideal-probability matched classical sampling, five seeds"})
        thresholds[name] = {"sample_ids": manifest["secondary_sample_ids"], "rows": rows,
                            "development_grid": manifest["tuning"]["legacy_threshold_grid"]}
        sample = load_sample(run, manifest["secondary_sample_ids"])
        config = GASConfig(**manifest["config"])
        weights = []
        for weight in (0.0, 0.1, 0.25, 0.5, 0.75, 1.0):
            values, latencies = [], []
            with (output / f"{name}_mmr_weight_{weight}_traces.jsonl").open("w") as handle:
                for qid in manifest["secondary_sample_ids"]:
                    features = take_features(sample[qid], config.candidate_limit)
                    result = select_classical(features, "mmr", config, mmr_weight=weight)
                    values.append(selection_metrics(result, qrels[qid]))
                    latencies.append(result.timings_ms["total_ms"])
                    handle.write(json.dumps({"qid": qid, "result": result.to_dict()}, allow_nan=False) + "\n")
            weights.append({"weight": weight,
                            "nDCG@5": float(np.mean([row["nDCG@5"] for row in values])),
                            "redundancy": float(np.mean([row["redundancy"] for row in values])),
                            "median_selector_ms": float(np.median(latencies))})
        gas_values = []
        for record in selected_records:
            scores = [selection_metrics(SelectionResult(**row), qrels[record["qid"]])
                      for row in record["methods"]["gas"]["per_seed_results"].values()]
            gas_values.append({key: float(np.mean([row[key] for row in scores]))
                               for key in ("nDCG@5", "redundancy")})
        mmr_curves[name] = {"sample_ids": manifest["secondary_sample_ids"], "points": weights,
                            "gas_sample_mean": {key: float(np.mean([row[key] for row in gas_values]))
                                                for key in ("nDCG@5", "redundancy")},
                            "primary_mmr_weight": manifest["mmr_tuning"]["selected_weight"],
                            "role": "Exploratory fixed-grid test sensitivity; all points reported; no primary retuning"}
        print(f"Legacy threshold sensitivity completed: {name}", flush=True)
    if scifact is None:
        raise ValueError("SciFact run required for the predetermined native synthesis case")
    native = []
    for n in (10, 12, 15):
        for bits in (2, 4, 6):
            cmd = [sys.executable, str(Path(__file__).resolve()), "native-worker", "--run", str(scifact),
                   "--pool", str(n), "--bits", str(bits)]
            try:
                completed = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=180)
                row = json.loads(completed.stdout.strip().splitlines()[-1])
            except subprocess.TimeoutExpired:
                row = {"pool": n, "bits": bits, "selected": 8, "status": "synthesis_timeout", "limit_seconds": 180}
            native.append(row)
            print(f"Native synthesis {n}/8, {bits} bits: {row['status']}", flush=True)
    _write_json(output / "additional.json", {"threshold_sensitivity": thresholds, "native_synthesis": native,
                                            "mmr_fixed_weight_sweep": mmr_curves,
                                            "native_case_rule": "First frozen SciFact secondary ID; fixed eight outputs",
                                            "native_timeout_seconds": 180})
    seal_run(output, {"schema": SCHEMA, "profile": "gas_additional_studies", "source_hashes": sources,
                      "parent_runs": parents, "analysis_source_sha256": _sha(Path(__file__)),
                      "hardware": hardware_record(),
                      "note": "Secondary threshold sensitivity and generic full-pool circuit synthesis; no primary retuning"})
    print(f"Sealed additional studies: {output}", flush=True)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run")
    run.add_argument("--runs", nargs=3, required=True)
    worker = sub.add_parser("native-worker")
    worker.add_argument("--run", required=True)
    worker.add_argument("--pool", type=int, required=True)
    worker.add_argument("--bits", type=int, required=True)
    args = parser.parse_args()
    native_worker(args) if args.command == "native-worker" else run_studies(args)
