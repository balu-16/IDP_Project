"""Independently cross-check every primary request using official trec_eval."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import statistics

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research import datasets
from research.selection import CandidateFeatures, SelectionResult, selection_metrics
from research.selection_experiment import verify_run


def crosscheck(run: Path, executable: str) -> dict:
    manifest = verify_run(run)
    name = manifest["canonical_dataset"]
    for relative, expected in manifest["freeze"]["files"].items():
        if datasets.sha256_file(datasets.DATA_ROOT / name / relative) != expected:
            raise ValueError("Input dataset changed")
    _, _, qrels = datasets.load_beir(name, "test")
    groups, by_query = {}, {}
    with (run / "traces.jsonl").open() as handle:
        for line in handle:
            record = json.loads(line)
            for method, payload in record["methods"].items():
                rows = payload.get("per_seed_results", {"deterministic": payload.get("result")})
                for seed, result in rows.items():
                    parsed = SelectionResult(**result)
                    groups.setdefault(f"{method}.{seed}", {})[record["qid"]] = parsed
                    by_query.setdefault(record["qid"], []).append(parsed)
    geometry_checks = 0
    geometry_ids = set()
    with (run / "full_features.jsonl").open() as handle:
        for line in handle:
            record = json.loads(line)
            features = CandidateFeatures.from_dict(record["features"])
            lookup = {did: i for i, did in enumerate(features.ids)}
            geometry_ids.add(record["qid"])
            for result in by_query[record["qid"]]:
                indices = [lookup[did] for did in result.selected_ids]
                vectors = features.embeddings[indices]
                pairs = np.clip(vectors @ vectors.T, 0, 1)[np.triu_indices(len(indices), 1)]
                redundancy = float(pairs.mean()) if len(pairs) else 0.0
                relevance = (features.cosine_scores[indices] + 1) / 2
                weight = result.config["diversity_weight"]
                utility = float(relevance.mean() - weight * redundancy)
                scale = (1 << result.config["coefficient_bits"]) - 1
                energy = -int(np.rint(scale * relevance).sum())
                if len(indices) > 1:
                    energy += int(np.rint(scale * 2 * weight / (len(indices) - 1) * pairs).sum())
                if abs(result.redundancy - redundancy) > 1e-9 or abs(result.utility - utility) > 1e-9:
                    raise ArithmeticError(f"Selected-set geometry mismatch: {name}/{record['qid']}/{result.method}")
                if result.energy != energy:
                    raise ArithmeticError(f"Selected-set integer energy mismatch: {name}/{record['qid']}/{result.method}")
                geometry_checks += 1
    if geometry_ids != set(manifest["test_ids"]):
        raise ValueError("Full-feature geometry coverage mismatch")
    comparisons, maximum_error = 0, 0.0
    aggregated = {}
    keys = {"ndcg_cut_5": "nDCG@5", "ndcg_cut_8": "nDCG@8",
            "recall_5": "Recall@5", "recall_8": "Recall@8", "P_5": "P@5", "recip_rank": "MRR@8"}
    with tempfile.TemporaryDirectory(prefix="gas_trec_crosscheck_") as directory:
        directory = Path(directory)
        qrel_path = directory / "judgments.qrels"
        with qrel_path.open("w") as handle:
            for qid, judgments in qrels.items():
                for did, grade in judgments.items():
                    handle.write(f"{qid} 0 {did} {grade}\n")
        for tag, rows in groups.items():
            path = directory / "ranking.trec"
            with path.open("w") as handle:
                for qid, result in rows.items():
                    for index, did in enumerate(result.ranked_ids, 1):
                        handle.write(f"{qid} Q0 {did} {index} {100 - index} {tag}\n")
            completed = subprocess.run([executable, "-q", "-m", "ndcg_cut.5,8", "-m", "recall.5,8",
                                         "-m", "P.5", "-m", "recip_rank", str(qrel_path), str(path)],
                                        capture_output=True, text=True, check=True)
            seen = set()
            for line in completed.stdout.splitlines():
                metric, qid, value = line.split()
                if qid == "all" or metric not in keys:
                    continue
                expected = selection_metrics(rows[qid], qrels[qid])[keys[metric]]
                error = abs(float(value) - expected)
                maximum_error = max(maximum_error, error)
                if error > 0.000051:
                    raise ArithmeticError(f"TREC metric mismatch: {name}/{tag}/{qid}/{metric}: {value} != {expected}")
                comparisons += 1
                aggregated.setdefault(tag.rsplit('.', 1)[0], {}).setdefault(keys[metric], []).append(float(value))
                seen.add((qid, metric))
            if len(seen) != len(rows) * len(keys):
                raise ValueError(f"Incomplete TREC cross-check coverage for {name}/{tag}")
            with path.open("w") as handle:
                for qid, result in rows.items():
                    for index, did in enumerate(result.ranked_ids[:5], 1):
                        handle.write(f"{qid} Q0 {did} {index} {100 - index} {tag}\n")
            truncated = subprocess.run([executable, "-q", "-m", "recip_rank", str(qrel_path), str(path)],
                                       capture_output=True, text=True, check=True)
            seen_mrr = set()
            for line in truncated.stdout.splitlines():
                metric, qid, value = line.split()
                if qid == "all":
                    continue
                expected = selection_metrics(rows[qid], qrels[qid])["MRR@5"]
                error = abs(float(value) - expected)
                maximum_error = max(maximum_error, error)
                if error > 0.000051:
                    raise ArithmeticError(f"TREC MRR@5 mismatch: {name}/{tag}/{qid}")
                comparisons += 1
                aggregated.setdefault(tag.rsplit('.', 1)[0], {}).setdefault("MRR@5", []).append(float(value))
                seen_mrr.add(qid)
            if seen_mrr != set(rows):
                raise ValueError("Incomplete TREC MRR@5 coverage")
    means = json.loads((run / "scores.json").read_text())["means"]
    aggregate_checks = 0
    for method, columns in aggregated.items():
        for metric, values in columns.items():
            if abs(statistics.fmean(values) - means[method][metric]) > 0.000051:
                raise ArithmeticError(f"Independent aggregate metric mismatch: {name}/{method}/{metric}")
            aggregate_checks += 1
    return {"dataset": name, "request_groups": len(groups), "query_count": len(manifest["test_ids"]),
            "compared_values": comparisons, "maximum_absolute_error": maximum_error,
            "independent_aggregate_checks": aggregate_checks, "selected_set_geometry_checks": geometry_checks,
            "tolerance": 0.000051, "note": "trec_eval prints four decimal places; all available primary requests checked",
            "manifest_sha256": hashlib.sha256((run / "manifest.json").read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs="+", required=True)
    parser.add_argument("--trec-eval", required=True)
    parser.add_argument("--trec-commit", required=True)
    args = parser.parse_args()
    results = [crosscheck(Path(path), args.trec_eval) for path in args.runs]
    payload = {"trec_eval_commit": args.trec_commit, "datasets": results,
               "helper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (Path(__file__).parent / "metric_crosscheck.json").write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, indent=2))
