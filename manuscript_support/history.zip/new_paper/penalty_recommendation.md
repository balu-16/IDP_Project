# SciFact penalty analysis — 17 October 2026

This is a recommendation based on the saved corrected SciFact artifacts, source
inspection, arithmetic analysis, and primary research. No dataset evaluation,
selector run, unit test, model inference, implementation change, or manuscript
change was performed for this analysis. Existing evaluations remain stopped.

The follow-up [hyperparameter recommendation](hyperparameter_recommendation.md)
expands this penalty-only analysis. It proposes eight bits for the next primary
candidate and retains the six-bit/0.05 setting below as an isolated comparison.
Neither proposal changes the implementation or starts evaluations.

## Recommendation

**Use diversity weight 0.05 as the next candidate, keeping six-bit coefficients,
15 candidates, eight outputs, all five seeds, and the existing search budgets.**
It is a defensible controlled experiment, not an empirically established optimum.
Compare it with 0, 0.075 and the existing 0.10 on development queries before
committing to another full SciFact test run. The current artifacts contain no
measured result for 0.05 or 0.075. A literature search cannot establish their
performance on this implementation.

The user is considering a weaker-penalty SciFact experiment before NFCorpus.
This proposal does not start that experiment or restart the earlier automatic
chain. Preserve the original corrected SciFact run and every reported outcome.

## Current setting and meaning

Authoritative run: `research/runs/20261017T055641Z_gas_scifact_corrected`.
Its manifest records `diversity_weight: 0.1` and `coefficient_bits: 6`.
The dataclass's generic default is 0.25, but development tuning selected 0.10
for the completed SciFact run. Report the evaluated setting, not the default.

The continuous objective implemented in `research/selection.py` is:

```text
U(S) = mean((1 + cosine(query, document_i)) / 2)
       - lambda * mean(max(0, cosine(document_i, document_j)))
```

Here the second mean is over distinct pairs among the eight selected documents.
This is a penalty on within-set similarity, not on query–document similarity.
Lambda is a coefficient, not a percentage of documents to remove or an accuracy
threshold. Reducing 0.10 to 0.05 halves the continuous penalty before rounding.

Because relevance is rescaled from cosine to `(1 + cosine) / 2`, maximizing this
objective is also equivalent to maximizing mean raw query cosine minus
`2 * lambda` times mean pair similarity. Numeric weights from differently
normalized formulas cannot be transferred directly.

The original [MMR paper](https://www.cs.cmu.edu/afs/cs/Web/People/jgc/publication/MMR_DiversityBased_Reranking_SIGIR_1998.pdf)
supports balancing query relevance with novelty. Its conventional lambda weights
relevance, whereas this implementation's lambda weights the similarity penalty.
The direction and scale differ; its illustrative 0.3/0.7 values are not justified
settings for our objective. Neither this source nor the GAS literature supplies
a universal best penalty for SciFact.

## Evidence already available

The saved development grid used the exact **quantized** optimizer:

| Diversity weight | Development nDCG@5 | Development redundancy |
|---|---:|---:|
| 0.10 | 0.666543 | 0.447474 |
| 0.25 | 0.650671 | 0.411274 |
| 0.50 | 0.573251 | 0.387845 |

Development cosine nDCG@5 was 0.666123. The old grid did not investigate any
positive weight below 0.10. Larger weights clearly sacrificed development
relevance. However, 0.10 itself slightly exceeded cosine in that development
comparison, so these data do **not** prove that it is too strong, or that a
weaker value will improve held-out relevance.

Existing test results also distinguish three effects:

| Existing method, lambda 0.10 | Test nDCG@5 | Redundancy |
|---|---:|---:|
| Exact continuous-objective optimizer | 0.635539 | 0.432094 |
| Exact six-bit integer optimizer | 0.632225 | 0.445078 |
| Bounded GAS on the six-bit integer objective | 0.631067 | 0.448951 |
| Cosine baseline | 0.636077 | 0.475640 |

The differences show that rounding and bounded search are relevant to the
observed trade-off. They do not isolate a unique causal explanation for every
query, nor prove that changing only lambda will recover the loss. GAS reached
the integer optimum on 69.87% of query-seed requests. Existing weight tuning used
the exact solver, rather than the actual bounded GAS algorithm.

These saved test results motivate diagnosis; they must not be repeatedly used
to choose and advertise the best-scoring penalty.

## Why six-bit rounding changes the recommendation

The code uses scale `2**6 - 1 = 63`. With eight selected documents, each pair
coefficient is:

```text
q_ij = round(63 * 2 * lambda / 7 * similarity_ij)
     = round(18 * lambda * similarity_ij)
```

Similarity is clipped to [0, 1]. The implementation uses `numpy.rint`, which
rounds halfway cases to the even integer; see the matching
[NumPy 1.26 documentation](https://numpy.org/doc/1.26/reference/generated/numpy.rint.html).

The following entries are derived arithmetic, **not benchmark measurements**:

| Weight | Pair coefficient at similarity 0.30 | At 0.50 | At 0.60 | At 0.80 | At 1.00 |
|---|---:|---:|---:|---:|---:|
| 0.025 | 0 | 0 | 0 | 0 | 0 |
| 0.050 | 0 | 0 | 1 | 1 | 1 |
| 0.075 | 0 | 1 | 1 | 1 | 1 |
| 0.100 | 1 | 1 | 1 | 1 | 2 |

- At 0.025, even the largest possible coefficient is 0.45 before rounding.
  Every pair coefficient therefore becomes zero. This is effectively the
  no-diversity integer objective, despite a positive continuous lambda.
- More generally, weights strictly below `7 / (4 * 63) = 1/36`, approximately
  0.02778, make every pair coefficient zero. At the exact mathematical boundary,
  a coefficient of 0.5 also rounds to zero; finite precision can affect boundary
  cases. There is no need to operate on that boundary.
- At 0.05, pair penalties are nonzero above approximately 0.55556 similarity.
  This retains a selective anti-similarity effect while dropping penalties on
  many moderately similar pairs. The threshold is a rounding artifact; it is
  not a validated semantic threshold for duplicate detection.
- At 0.075, the first nonzero threshold is approximately 0.37037. It is a useful
  intermediate development candidate if 0.05 removes too much diversity pressure.
- At 0.10, thresholds are approximately 0.27778 and 0.83333, yielding integer
  pair costs 0, 1 and 2.

Thus halving lambda does not halve every integer coefficient. The proposed 0.05
is meaningfully weaker under the existing arithmetic, while 0.025 would silently
erase the diversity term. Relevance is also quantized: one integer step is
1/63 in rescaled relevance, equivalent to approximately 0.031746 raw query cosine.

## Proposed development study before a full rerun

1. Retain the 161 recorded SciFact development query IDs and judgments. Use the
   existing cached corpus embeddings and the same representative passages.
2. Predeclare weights `{0, 0.05, 0.075, 0.10}`, six coefficient bits, and all
   five seeds `{0, 1, 2, 3, 4}`. Keep every other GAS setting fixed.
3. Evaluate the actual bounded GAS selector. Average seeds within query before
   computing mean development nDCG@5. Retain all seed outcomes. Record redundancy,
   exact-optimum gap, selection latency, and the fraction of nonzero pair costs.
4. For this proposed relevance-first revision, choose the highest development
   mean nDCG@5. Resolve numerical ties within 1e-12 by lower redundancy, then
   smaller lambda. Document that this selection rule differs from the original
   diversity-first rule subject to a 0.01 quality allowance. Do not silently
   relabel it as the original preregistered experiment.
5. Treat weight zero as a diagnostic control. With the current strictly improving
   search, cosine-top-eight initialization already optimizes its monotone rounded
   linear relevance objective. It therefore returns the cosine set. If zero wins,
   report that outcome rather than forcing a positive weight to claim improvement.
6. Freeze the development-selected configuration, then collect one separately
   tagged full SciFact run. Keep the original 0.10 result. Do not sweep multiple
   penalties on the test set and publish only the winner.

Since SciFact test results have already informed this revision, a new SciFact
run is a transparent follow-up experiment, not a completely untouched final
confirmation set. Select parameters on development data and document the
iteration. Preserve genuinely unconsulted evaluation evidence for stronger
generalization claims. The risk of selection bias from repeatedly optimizing
against finite evaluation data is documented by
[Cawley and Talbot](https://jmlr.org/papers/v11/cawley10a.html).

The existing CLI supports an explicit future weight without changing research
source: `--gas-weight 0.05 --gas-coefficient-bits 6`. Omitting `--gas-weight`
invokes the original 0.10/0.25/0.50 tuning grid; it will not test these weaker
candidates automatically. No command was executed here.

## Precision and speed: separate questions

An optional later development comparison at fixed lambda can examine eight-bit
coefficients. It would help diagnose the rounding effect suggested by the
existing continuous/integer optimizer difference. Do not change both precision
and lambda in a single experiment and attribute all gains to the penalty.
Different precision also changes logical arithmetic resource requirements.

Changing lambda does not reduce the 6,435 feasible subsets. It cannot promise
lower median latency or a wall-clock speedup over greedy/exact classical
selection. [GAS research](https://arxiv.org/abs/1912.04088) discusses oracle-dependent
optimization speedups; changing a relevance penalty does not establish such a
speedup for this classical compact simulator.

Other datasets can behave differently, as motivated by the heterogeneous
[BEIR benchmark](https://arxiv.org/abs/2104.08663). They measure generalization;
they do not repair a SciFact trade-off. Investigating the weaker candidate on
development data first is a reasonable way to control the cost of the next
experiment, while keeping the current negative/inconclusive results intact.
