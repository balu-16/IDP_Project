"""Verify local benchmark files against the official BEIR ZIP archives."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research.datasets import freeze_record
from research.config_frozen import DATASETS

EXPECTED = {"scifact": "5f7d1de60b170fc8027bb7898e2efca1",
            "nfcorpus": "a89dba18a62ef92f7d323ec890a0d38d",
            "fiqa": "17918ed23cd04fb15047f73e6c3bd9d9"}


def verify():
    records = {}
    for name, expected in EXPECTED.items():
        archive = ROOT / "research" / "downloads" / f"{name}.zip"
        payload = archive.read_bytes()
        if hashlib.md5(payload).hexdigest() != expected:
            raise ValueError(f"Official archive MD5 mismatch for {name}")
        record = freeze_record(name)
        checks = {}
        with zipfile.ZipFile(archive) as zipped:
            for relative, local_digest in record["files"].items():
                official_digest = hashlib.sha256(zipped.read(f"{name}/{relative}")).hexdigest()
                checks[relative] = {"sha256": local_digest, "matches_official": official_digest == local_digest}
                if official_digest != local_digest:
                    raise ValueError(f"Local file differs from official BEIR archive: {name}/{relative}")
        records[name] = {"archive_url": DATASETS[name]["source_url"], "archive_md5": expected,
                         "archive_sha256": hashlib.sha256(payload).hexdigest(), "files": checks}
        print(name, "all", len(checks), "input files match the official BEIR archive", flush=True)
    path = Path(__file__).parent / "dataset_source_verification.json"
    path.write_text(json.dumps({"source": "https://github.com/beir-cellar/beir#beers-available-datasets",
                                "datasets": records}, indent=2) + "\n")


if __name__ == "__main__":
    verify()
