"""Standalone static and interactive plots of verified experiment summaries."""
from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from new_paper.generate_gas_tables import METHODS, NAMES, ORDER

HERE = Path(__file__).resolve().parent
NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", NS)
ET.register_namespace("xlink", "http://www.w3.org/1999/xlink")


def generate():
    audit = json.loads((HERE / "reproducibility.json").read_text())
    output = HERE / "figures"
    output.mkdir(exist_ok=True)
    plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "svg.fonttype": "none"})
    styles = {
        "gas": ("#c62828", "D"), "cosine": ("#4d4d4d", "o"), "mmr": ("#000000", "s"),
        "greedy": ("#1565c0", "^"), "exact_quantized": ("#1976d2", "P"),
        "exact_float": ("#42a5f5", "X"), "fusion": ("#795548", "v"),
        "random": ("#ff8f00", "h"), "legacy_grover": ("#8e24aa", "p"),
        "neural_l2_matched": ("#2e7d32", "o"), "neural_l6_matched": ("#00695c", "s"),
        "neural_l2_top64": ("#66bb6a", "^"), "neural_l6_top64": ("#26a69a", "D")}
    legend, groups = [], {}
    for timing_key, filename, xlabel in (
        ("total_ms", "quality_selector_latency", "Median selector latency\n(ms; log scale)"),
        ("online_total_ms", "quality_online_latency", "Median composed online latency\n(ms; log scale)")):
        fig, axes = plt.subplots(1, 3, figsize=(11, 4.7))
        for axis, name in zip(axes, ORDER):
            dataset = audit["primary_runs"][name]
            for method, label in METHODS.items():
                quality = dataset["means"][method]["nDCG@5"]
                latency = dataset["execution"][method][timing_key]["median"]
                color, marker = styles[method]
                point = axis.scatter(latency, quality, color=color, marker=marker,
                                     s=60 if method == "gas" else 36, alpha=.95,
                                     linewidths=.7, edgecolors="white", label=label,
                                     zorder=4 if method == "gas" else 3)
                identity = f"{name}__{method}__point"
                point.set_gid(identity)
                groups[identity] = (method, f"{NAMES[name]}: {label}; nDCG@5={quality:.6f}; "
                                    f"median latency={latency:.3f} ms; queries={len(dataset['manifest']['test_ids'])}")
                if method == "gas":
                    text = axis.annotate("GAS", (latency, quality), xytext=(5, -12),
                                         textcoords="offset points", color=color, fontweight="bold")
                    text.set_gid(f"{name}__{method}__label")
            axis.set(xscale="log", title=f"{NAMES[name]} ({len(dataset['manifest']['test_ids'])} queries)",
                     xlabel=xlabel, ylabel="Mean nDCG@5")
            axis.grid(True, alpha=.22, which="both")
            axis.margins(x=.14, y=.22)
        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc="lower center", ncol=4, frameon=False, fontsize=8)
        fig.suptitle("Retrieval quality and measured computational cost", fontsize=12)
        fig.text(.5, .19, "Point estimates only. Paired confidence intervals determine the primary quality target.",
                 ha="center", fontsize=8)
        fig.tight_layout(rect=(0, .24, 1, .95))
        for extension in ("pdf", "svg", "png"):
            fig.savefig(output / f"{filename}.{extension}", dpi=200, bbox_inches="tight")
        plt.close(fig)
        svg_path = output / f"{filename}.svg"
        tree = ET.parse(svg_path)
        for element in tree.iter():
            identity = element.get("id", "")
            parts = identity.split("__")
            if len(parts) == 3 and parts[1] in METHODS:
                element.set("data-method", parts[1])
                if identity in groups:
                    title = ET.Element(f"{{{NS}}}title")
                    title.text = groups[identity][1]
                    element.insert(0, title)
        inline = ET.tostring(tree.getroot(), encoding="unicode")
        controls = " ".join(f'<label><input type="checkbox" value="{method}" checked>{html.escape(label)}</label>'
                            for method, label in METHODS.items())
        document = ('<!doctype html><html lang="en"><meta charset="utf-8"><title>Retrieval tradeoffs</title>'
                    '<style>body{font:16px system-ui;margin:24px;max-width:1400px}label{display:inline-block;'
                    'margin:5px 12px 5px 0}svg{width:100%;height:auto}p{line-height:1.5}</style>'
                    '<h1>Retrieval quality and latency</h1><p>Hover over points for exact values. '
                    'Use the controls to compare methods. These are full-test point estimates, '
                    'with stochastic metrics averaged within query. Confidence intervals and limitations '
                    'are in the accompanying report.</p><div>' + controls + '</div>' + inline +
                    '<script>document.querySelectorAll("input").forEach(c=>c.addEventListener("change",()=>{'
                    'document.querySelectorAll("[data-method]").forEach(e=>{if(e.dataset.method===c.value)'
                    'e.style.display=c.checked?"":"none"})}));</script></html>')
        (output / f"{filename}.html").write_text(document)
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.8))
    curves = audit["additional_results"]["mmr_fixed_weight_sweep"]
    for axis, name in zip(axes, ORDER):
        curve = curves[name]
        points = curve["points"]
        axis.plot([p["redundancy"] for p in points], [p["nDCG@5"] for p in points],
                  color="#455a64", marker="o", markersize=4, linewidth=1.2, label="Fixed-weight MMR")
        for point in points:
            axis.annotate(f"{point['weight']:g}", (point["redundancy"], point["nDCG@5"]),
                          xytext=(4, 4), textcoords="offset points", fontsize=7)
        gas = curve["gas_sample_mean"]
        axis.scatter(gas["redundancy"], gas["nDCG@5"], marker="D", color="#c62828", s=55,
                     zorder=4, label="GAS, same queries")
        axis.set(title=f"{NAMES[name]} ({len(curve['sample_ids'])} queries)",
                 xlabel="Mean embedding redundancy (lower is better)", ylabel="Mean nDCG@5")
        axis.grid(True, alpha=.22)
        axis.margins(x=.18, y=.18)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False)
    fig.suptitle("Exploratory relevance/diversity sensitivity", fontsize=12)
    fig.text(.5, .10, "Labels show fixed MMR diversity weights; no test point retunes the primary baseline.",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, .17, 1, .95))
    for extension in ("pdf", "svg", "png"):
        fig.savefig(output / f"quality_diversity.{extension}", dpi=200, bbox_inches="tight")
    plt.close(fig)
    report = HERE / "reproducibility_report.md"
    with report.open("a") as handle:
        handle.write("\n## Quality and latency visualizations\n\n"
                     "[Interactive selector plot](figures/quality_selector_latency.html), "
                     "[interactive online plot](figures/quality_online_latency.html). "
                     "Standalone PDF/SVG/PNG exports are in `figures/`.\n\n"
                     "![Quality and selector latency](figures/quality_selector_latency.png)\n\n"
                     "The exploratory MMR curve uses the same 64 secondary queries per dataset for every "
                     "point and for GAS; it must not be mixed with full-test means.\n\n"
                     "![Exploratory relevance and diversity](figures/quality_diversity.png)\n")
    manifest = {"input_audit_sha256": hashlib.sha256((HERE / "reproducibility.json").read_bytes()).hexdigest(),
                "plot_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "files": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir()
                          if p.is_file() and p.name != "manifest.json"}}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Created static and interactive tradeoff plots in {output}")


if __name__ == "__main__":
    generate()
