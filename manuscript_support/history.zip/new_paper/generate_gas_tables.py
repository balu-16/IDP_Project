"""Generate the revised manuscript and companion evidence from sealed GAS runs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research.selection_experiment import verify_run

NAMES = {"scifact": "SciFact", "nfcorpus": "NFCorpus", "fiqa": "FiQA"}
ORDER = ("scifact", "nfcorpus", "fiqa")
METHODS = {
    "cosine": "Cosine", "fusion": "RRF", "mmr": "MMR", "greedy": "Greedy",
    "exact_quantized": "Exact integer", "exact_float": "Exact float", "random": "Random search",
    "gas": "GAS", "legacy_grover": "Legacy Grover (64)",
    "neural_l2_matched": "Cross-encoder L2 (15)", "neural_l6_matched": "Cross-encoder L6 (15)",
    "neural_l2_top64": "Cross-encoder L2 (64)", "neural_l6_top64": "Cross-encoder L6 (64)"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(value, places=3):
    value = float(value)
    return f"{0.0 if round(value, places) == 0 else value:.{places}f}"


def interval(row):
    return f"[{row['ci_low']:+.4f}, {row['ci_high']:+.4f}]"


def table(columns, headers, rows):
    return "\n".join([r"\begin{tabular}{" + columns + "}", r"\toprule", headers + r"\\",
                       r"\midrule", *[" & ".join(row) + r"\\" for row in rows],
                       r"\bottomrule", r"\end{tabular}"]) + "\n"


def write(output, name, content):
    (output / name).write_text(content)


def generate(args):
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    runs, paths, manifests = {}, {}, {}
    for path_arg in args.runs:
        path = Path(path_arg).resolve()
        manifest = verify_run(path)
        name = manifest["canonical_dataset"]
        if name not in ORDER or name in runs or "scores.json" not in manifest["result_hashes"]:
            raise ValueError("Expected one evaluated, sealed run for each of SciFact/NFCorpus/FiQA")
        runs[name] = json.loads((path / "scores.json").read_text())
        paths[name], manifests[name] = path, manifest
        if set(manifest["methods"]) != set(METHODS):
            raise ValueError(f"Incomplete comparator coverage for {name}")
    if set(runs) != set(ORDER):
        raise ValueError("All three datasets are required")
    reference = manifests[ORDER[0]]
    fields = set(reference["config"]) - {"diversity_weight"}
    for name in ORDER:
        current = manifests[name]
        if not current["provenance"].get("tokenizer_full_text_offsets"):
            raise ValueError("Manuscript requires the corrected full-text tokenizer pipeline")
        if any(current["config"][key] != reference["config"][key] for key in fields):
            raise ValueError("Primary operating-point settings differ across datasets")
        if current["source_hashes"] != reference["source_hashes"] or current["seeds"] != reference["seeds"]:
            raise ValueError("Primary source or seed protocol differs across datasets")
        for label in ("l2", "l6"):
            if any(current["neural_models"][label][key] != reference["neural_models"][label][key]
                   for key in ("id", "revision")):
                raise ValueError("Neural model revisions drifted across datasets")
    study_path = Path(args.studies).resolve()
    study_manifest = verify_run(study_path)
    if study_manifest["profile"] != "gas_studies":
        raise ValueError("Expected the secondary-studies artifact schema")
    for parent in study_manifest["parent_runs"]:
        if sha(Path(parent["run"]) / "manifest.json") != parent["manifest_sha256"]:
            raise ValueError("Parent run changed after secondary studies")
    studies = json.loads((study_path / "studies.json").read_text())
    additional_path = Path(args.additional).resolve()
    additional_manifest = verify_run(additional_path)
    if additional_manifest["profile"] != "gas_additional_studies":
        raise ValueError("Expected the additional-study artifact schema")
    if sha(Path(__file__).parent / "additional_studies.py") != additional_manifest["analysis_source_sha256"]:
        raise ValueError("Additional-study analysis source changed after collection")
    for parent in additional_manifest["parent_runs"]:
        if sha(Path(parent["run"]) / "manifest.json") != parent["manifest_sha256"]:
            raise ValueError("Additional-study parent changed")
    additional = json.loads((additional_path / "additional.json").read_text())

    rows = []
    for name in ORDER:
        m = manifests[name]
        rows.append([NAMES[name], f"{m['n_corpus']:,}", str(len(m["dev_ids"])), str(len(m["test_ids"])),
                     number(m["config"]["diversity_weight"], 2), number(m["mmr_tuning"]["selected_weight"], 2)])
    write(output, "dataset_table.tex", table("lrrrrr", r"Dataset & Parents & Dev. & Test & $\lambda_{\rm GAS}$ & $\lambda_{\rm MMR}$", rows))

    rows = []
    for method, label in METHODS.items():
        row = [r"\textbf{GAS}" if method == "gas" else label]
        for name in ORDER:
            metrics = runs[name]["means"][method]
            row += [number(metrics[k]) for k in ("nDCG@5", "nDCG@8", "Recall@8", "redundancy")]
        rows.append(row)
    header = r"& \multicolumn{4}{c}{SciFact} & \multicolumn{4}{c}{NFCorpus} & \multicolumn{4}{c}{FiQA}\\" + "\n"
    header += r"Method & n@5 & n@8 & R@8 & Red.$\downarrow$ & n@5 & n@8 & R@8 & Red.$\downarrow$ & n@5 & n@8 & R@8 & Red.$\downarrow$"
    write(output, "effectiveness.tex", table("l" + "r" * 12, header, rows))

    rows = []
    for method, label in METHODS.items():
        row = [label]
        for name in ORDER:
            execution = runs[name]["execution"][method]
            row += [number(execution[key][stat], 1) for key in ("total_ms", "online_total_ms") for stat in ("median", "p95")]
        rows.append(row)
    header = r"& \multicolumn{4}{c}{SciFact (ms)} & \multicolumn{4}{c}{NFCorpus (ms)} & \multicolumn{4}{c}{FiQA (ms)}\\" + "\n"
    header += r"Method & S50 & S95 & O50 & O95 & S50 & S95 & O50 & O95 & S50 & S95 & O50 & O95"
    write(output, "latency.tex", table("l" + "r" * 12, header, rows))

    rows, primary_text = [], []
    for name in ORDER:
        target = runs[name]["primary_target"]
        quality, redundancy = target["quality_ci"], target["redundancy_ci"]
        passed = "Yes" if target["met"] else "No"
        rows.append([NAMES[name], f"{quality['mean_diff']:+.4f}", interval(quality),
                     f"{redundancy['mean_diff']:+.4f}", interval(redundancy), passed])
        primary_text.append(f"{NAMES[name]}: GAS-minus-MMR nDCG@5 was {quality['mean_diff']:+.4f} "
                            f"(95\\% CI {interval(quality)}), and redundancy changed by "
                            f"{redundancy['mean_diff']:+.4f} (95\\% CI {interval(redundancy)}).")
    write(output, "primary_statistics.tex", table("lrrrrc", r"Dataset & $\Delta$ n@5 & 95\% CI & $\Delta$ redundancy & 95\% CI & Joint target", rows))

    rows = []
    for name in ORDER:
        for method in ("cosine", "neural_l6_matched", "neural_l6_top64"):
            comp = runs[name]["comparisons_nDCG@5_gas_minus_baseline"][method]
            rows.append([NAMES[name], METHODS[method], f"{comp['mean_diff']:+.4f}", interval(comp),
                         number(comp["p_value"], 4), "Yes" if runs[name]["holm"][method]["significant"] else "No"])
    write(output, "comparisons.tex", table("llrrrc", r"Dataset & Comparator & $\Delta$ n@5 & 95\% CI & Raw $p$ & Holm reject", rows))

    rows = []
    statuses, candidate_coverage, resource_ranges = {}, {}, {}
    from research.datasets import load_beir
    for name in ORDER:
        scores = runs[name]
        rows.append([NAMES[name], number(scores["means"]["gas"]["quantized_optimum_hit"]),
                     number(scores["means"]["gas"]["quantized_energy_gap"]),
                     number(scores["means"]["gas"]["float_utility_gap"], 4),
                     number(scores["means"]["random"]["quantized_optimum_hit"]),
                     number(scores["means"]["greedy"]["quantized_optimum_hit"])])
        _, _, qrels = load_beir(name, "test")
        widths, recalls15, recalls64, phase_calls = [], [], [], []
        fallback = 0
        with (paths[name] / "traces.jsonl").open() as handle:
            for line in handle:
                record = json.loads(line)
                relevant = set(qrels[record["qid"]])
                recalls15.append(len(relevant & set(record["candidate_ids"])) / len(relevant))
                recalls64.append(len(relevant & set(record["shortlist_ids"])) / len(relevant))
                for result in record["methods"]["gas"]["per_seed_results"].values():
                    widths.append(result["resources"]["logical_total_qubits"])
                    phase_calls.append(result["counts"]["phase_oracle_calls"])
                fallback += sum(r["status"] == "fallback" for r in record["methods"]["legacy_grover"]["per_seed_results"].values())
        import numpy as np
        statuses[name] = {"gas": scores["execution"]["gas"]["status_counts"], "legacy_fallback_requests": fallback,
                          "gas_mean_phase_calls": float(np.mean(phase_calls))}
        candidate_coverage[name] = {"Recall@15": float(np.mean(recalls15)), "Recall@64": float(np.mean(recalls64))}
        resource_ranges[name] = [min(widths), max(widths)]
    write(output, "optimization.tex", table("lrrrrr", r"Dataset & GAS hit & Int. gap & Float gap & Random hit & Greedy hit", rows))

    rows = []
    labels = {"pool_10": "Pool 10", "pool_12": "Pool 12", "pool_15": "Pool 15 (reference)", "pool_20": "Pool 20",
              "bits_2": "2-bit coefficients", "bits_4": "4-bit coefficients", "no_diversity": r"$\lambda=0$"}
    for key, label in labels.items():
        row = [label]
        for name in ORDER:
            result = studies[name]["ablations"][key]
            row += [number(result["means"]["gas"]["nDCG@5"]), number(result["means"]["gas"]["redundancy"]),
                    number(result["execution"]["gas"]["total_ms"]["median"], 1)]
        rows.append(row)
    header = r"& \multicolumn{3}{c}{SciFact} & \multicolumn{3}{c}{NFCorpus} & \multicolumn{3}{c}{FiQA}\\" + "\n"
    header += r"Configuration & n@5 & Red. & ms & n@5 & Red. & ms & n@5 & Red. & ms"
    write(output, "ablations.tex", table("l" + "r" * 9, header, rows))

    rows = []
    for row in additional["native_synthesis"]:
        if row["status"] == "completed":
            rows.append([str(row["pool"]), str(row["bits"]), str(row["qubits"]), str(row["depth"]),
                         str(row["gates"].get("cx", 0)), number(row["transpile_ms"], 1)])
        else:
            rows.append([str(row["pool"]), str(row["bits"]), "--", "--", "--", r"$>180$ s"])
    write(output, "circuit_resources.tex", table("rrrrrr", r"Pool & Bits & Qubits & Depth & CX gates & Compile ms", rows))
    rows = []
    for index, threshold in enumerate((0.3, 0.5, 0.7)):
        row = [str(threshold)]
        for name in ORDER:
            values = additional["threshold_sensitivity"][name]["rows"][index]
            row += [number(values["nDCG@5"]), number(100 * values["fallback_fraction"], 1)]
        rows.append(row)
    header = r"& \multicolumn{2}{c}{SciFact} & \multicolumn{2}{c}{NFCorpus} & \multicolumn{2}{c}{FiQA}\\" + "\n"
    header += r"Threshold & n@5 & Fallback\% & n@5 & Fallback\% & n@5 & Fallback\%"
    write(output, "threshold_sensitivity.tex", table("r" * 7, header, rows))

    means = [runs[n]["means"]["gas"]["nDCG@5"] for n in ORDER]
    met_count = sum(runs[n]["primary_target"]["met"] for n in ORDER)
    latencies = [runs[n]["execution"]["gas"]["total_ms"]["median"] for n in ORDER]
    abstract = (f"Across SciFact, NFCorpus, and FiQA (1,271 test queries), mean GAS nDCG@5 was "
                f"{means[0]:.3f}, {means[1]:.3f}, and {means[2]:.3f}, respectively. "
                f"The joint quality-preservation and redundancy-reduction target against independently tuned MMR "
                f"was met on {met_count} of three datasets. Median selector latency ranged from "
                f"{min(latencies):.1f} to {max(latencies):.1f} ms, including exhaustive classical energy preparation.")
    write(output, "abstract_findings.tex", abstract + "\n")
    write(output, "primary_findings.tex", " ".join(primary_text) + "\n")
    coverage = " ".join(f"{NAMES[n]} candidate recall was {candidate_coverage[n]['Recall@15']:.3f} at 15 "
                         f"and {candidate_coverage[n]['Recall@64']:.3f} at 64." for n in ORDER)
    write(output, "coverage_findings.tex", coverage + "\n")
    execution = " ".join(f"{NAMES[n]} used a mean of {statuses[n]['gas_mean_phase_calls']:.1f} phase calls "
                          f"per seeded request; legacy no-marked fallback occurred in "
                          f"{statuses[n]['legacy_fallback_requests']}/{5 * len(manifests[n]['test_ids'])} requests."
                          for n in ORDER)
    write(output, "execution_findings.tex", execution + "\n")
    hardware = manifests[ORDER[0]]["hardware"]
    write(output, "hardware.tex", f"{hardware['cpu_model']}, {hardware['logical_cpus']} logical CPUs, "
          f"{hardware['ram_bytes'] / 2**30:.1f} GiB RAM; two CPU compute threads. "
          f"Python {hardware['python'].split()[0]}, NumPy {hardware['packages']['numpy']}, "
          f"PyTorch {hardware['packages']['torch']}, Qiskit {hardware['packages']['qiskit']}, "
          f"Aer {hardware['packages']['qiskit-aer']}, "
          f"and sentence-transformers {hardware['packages']['sentence-transformers']}.\n")
    write(output, "width_findings.tex", " ".join(f"{NAMES[n]} requires {resource_ranges[n][0]}--{resource_ranges[n][1]} "
          "logical decision-plus-value qubits under the conservative width calculation." for n in ORDER) + "\n")

    conclusion = (
        "This study evaluated Grover Adaptive Search as a fixed-cardinality evidence selector within a "
        "classical document-retrieval pipeline. The revised formulation chooses documents jointly for query "
        "relevance and embedding redundancy, then uses cosine scores to order the selected evidence. "
        "Complete SciFact, NFCorpus, and FiQA test sets were compared with independently tuned MMR, "
        "fusion, greedy and exact optimizers, matched random search, neural cross-encoders, and the legacy "
        "Grover reranker. "
        f"The prespecified joint quality-preservation and redundancy-reduction target was met on {met_count} "
        "of the three datasets. These findings therefore support only the dataset-specific tradeoffs reported "
        "in the results, rather than a general improvement in retrieval accuracy. The compact simulator "
        "explicitly includes exhaustive classical objective preparation, so its measurements cannot establish "
        "a physical quantum speedup or lower deployment cost. The additional pool-size, coefficient-precision, "
        "optimization-gap, and resource studies characterize practical limits of this implementation. Future "
        "work should implement scalable state preparation and reversible oracles, evaluate realistic noise, "
        "and test whether reduced embedding redundancy improves downstream answer quality."
    )
    if not 150 <= len(conclusion.split()) <= 200:
        raise ValueError("Conclusion must contain 150--200 words")
    write(output, "conclusion.tex", conclusion + "\n")

    audit = {"primary_runs": {n: {"path": str(paths[n].relative_to(ROOT)),
             "manifest_sha256": sha(paths[n] / "manifest.json"), "manifest": manifests[n],
             "means": runs[n]["means"], "execution": runs[n]["execution"], "target": runs[n]["primary_target"],
             "nDCG_comparisons": runs[n]["comparisons_nDCG@5_gas_minus_baseline"], "holm": runs[n]["holm"]}
             for n in ORDER}, "secondary_run": str(study_path.relative_to(ROOT)),
             "secondary_manifest_sha256": sha(study_path / "manifest.json"),
             "additional_run": str(additional_path.relative_to(ROOT)),
             "additional_manifest_sha256": sha(additional_path / "manifest.json"),
             "additional_results": additional,
             "generator_sha256": sha(__file__), "candidate_coverage": candidate_coverage,
             "status_counts": statuses, "logical_qubit_ranges": resource_ranges,
             "conclusion_word_count": len(conclusion.split())}
    (output.parent / "reproducibility.json").write_text(json.dumps(audit, indent=2, allow_nan=False) + "\n")
    report = ["# Evaluation and reproducibility report", "", abstract, "", "## Verified primary runs", ""]
    for name in ORDER:
        report += [f"- {NAMES[name]}: `{paths[name].relative_to(ROOT)}`; manifest SHA-256 "
                   f"`{sha(paths[name] / 'manifest.json')}`."]
    report += ["", "## Protocol", "", "Full test sets; 15 candidates, eight outputs, five seeds; "
               "development-only tuning. GAS and exact controls share the objective. MMR is tuned independently. "
               "Cross-encoders retain neural ordering. Classical energy enumeration is charged to GAS.",
               "", "## Primary joint target", "", *primary_text, "", f"Passed on {met_count}/3 datasets.",
               "", "## Candidate coverage", "", coverage, "", "## Execution", "", execution,
               "", "## Secondary studies", "", f"Sealed run: `{study_path.relative_to(ROOT)}`. "
               "Pool sizes 10/12/15/20 keep eight outputs. Precision 2/4/6 and zero-diversity studies use the "
               "64 IDs declared in each parent manifest. They are secondary samples, not full-set effectiveness.",
               "", "## Isolated feature-level memory (MiB)", "", "| Method | SciFact | NFCorpus | FiQA |",
               "|---|---:|---:|---:|"]
    for method in studies[ORDER[0]]["memory"]:
        report.append("| " + METHODS[method] + " | " + " | ".join(
            number(studies[n]["memory"][method]["process_peak_rss_bytes"] / 2**20, 1) for n in ORDER) + " |")
    report += ["", "Each memory entry is a fresh process including Python/libraries and its neural weights. "
               "It excludes the common corpus, retrieval index, and embedding encoder. It is not full-system RAM "
               "or proof of deployment cost savings.", "", "## Timing and limits", "", "S50/S95: selector median/P95; "
               "O50/O95: query encoding + classical candidate retrieval + representative features + selector. "
               "Corpus/model loading is offline. Seeded requests are measured individually. Runs were sequential "
               "on a shared desktop; background load and thread settings are recorded. No physical QPU was used. "
               "Small circuit counts use generic state preparation and do not demonstrate scalable full-pool gates. "
               "No dollar, energy, OCR, generation-quality, or publication guarantee is inferred.",
               "", "Raw metrics, confidence intervals, configurations, versions, input checksums, and source hashes "
               "are retained in `reproducibility.json` and the sealed run directories."]
    report += ["", "## Selector CPU cost (median CPU milliseconds)", "",
               "| Method | SciFact | NFCorpus | FiQA |", "|---|---:|---:|---:|"]
    for method, label in METHODS.items():
        report.append("| " + label + " | " + " | ".join(
            number(runs[n]["execution"][method]["cpu_ms"]["median"], 2) for n in ORDER) + " |")
    report += ["", "CPU cost uses the same selector boundary as S50/S95. It excludes shared query encoding "
               "and upstream retrieval, and is a resource proxy rather than a monetary price.",
               "", "## Legacy threshold sensitivity (secondary samples)", "",
               "| Dataset | Threshold | nDCG@5 | Fallback queries |", "|---|---:|---:|---:|"]
    for name in ORDER:
        for row in additional["threshold_sensitivity"][name]["rows"]:
            report.append(f"| {NAMES[name]} | {row['threshold']} | {row['nDCG@5']:.4f} | "
                          f"{row['fallback_queries']}/{row['queries']} |")
    report += ["", "This sweep uses the legacy matched ideal-probability classical-sampling control. "
               "The marking/fallback condition is shared with the legacy Grover policy. It does not retune "
               "the primary threshold from test outcomes.", "", "## Native full-pool synthesis", "",
               "| Pool | Output | Bits | Qubits | Depth | CX | Status |", "|---:|---:|---:|---:|---:|---:|---|"]
    for row in additional["native_synthesis"]:
        report.append(f"| {row['pool']} | {row['selected']} | {row['bits']} | {row.get('qubits', '--')} | "
                      f"{row.get('depth', '--')} | {row.get('gates', {}).get('cx', '--')} | {row['status']} |")
    report += ["", "These are generic, one-iteration native circuits for the first frozen SciFact secondary "
               "ID. State preparation is included. Synthesis is not full-state simulation or QPU execution; "
               "180-second timeouts remain explicit. Small numerical equivalence checks pass separately."]
    report += ["", "## Exploratory fixed-weight MMR sensitivity", "",
               "All six fixed weights are reported on the same secondary samples. No test point replaces the "
               "development-selected primary baseline. A primary win against nDCG-selected MMR does not "
               "establish dominance over MMR's complete relevance/diversity tradeoff.", "",
               "| Dataset | MMR diversity weight | nDCG@5 | Redundancy |", "|---|---:|---:|---:|"]
    for name in ORDER:
        for row in additional["mmr_fixed_weight_sweep"][name]["points"]:
            report.append(f"| {NAMES[name]} | {row['weight']} | {row['nDCG@5']:.4f} | {row['redundancy']:.4f} |")
    report += ["", "## Shared offline preparation", "",
               "| Dataset | Encoded chunks | Corpus loading/encoding s | BM25 construction s | Query encoding s |",
               "|---|---:|---:|---:|---:|"]
    for name in ORDER:
        manifest = manifests[name]
        offline = manifest["offline_timings_ms"]
        report.append(f"| {NAMES[name]} | {manifest['provenance']['n_chunks']} | "
                      f"{offline['dataset_and_corpus_encoding']/1000:.1f} | "
                      f"{offline['bm25_build']/1000:.2f} | {offline['test_query_encoding']/1000:.2f} |")
    (output.parent / "reproducibility_report.md").write_text("\n".join(report) + "\n")
    print(f"Generated verified GAS paper inputs in {output}; conclusion {len(conclusion.split())} words")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", nargs=3, required=True)
    parser.add_argument("--studies", required=True)
    parser.add_argument("--additional", required=True)
    parser.add_argument("--output", default=str(Path(__file__).parent / "gas_generated"))
    generate(parser.parse_args())
